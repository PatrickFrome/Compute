# METAENGINE Handoff Capsules

Полная капсула передачи контекста между сессиями/чатами METAENGINE.

**Точка старта: [`00_START_HERE_CAPSULE.md`](00_START_HERE_CAPSULE.md)**

Архив целиком: `METAENGINE_HANDOFF_CAPSULE_2026-09-21.tar.gz`
(также доступен как asset релиза `capsule-2026-09-21`).

⚠️ Репозиторий приватный: внутри `01_CREDENTIALS_AND_ENDPOINTS.md` запечатаны
токены и пароли. НЕ делать публичным, не форкать наружу.
