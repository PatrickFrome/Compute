#ifndef EVENT_H
#define EVENT_H

#include "curl_prelude.h"

#include "core.h"

#ifdef __linux__
#  define WAIT_USE_EPOLL
#elif defined(__APPLE__) || defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
#  define WAIT_USE_KQUEUE
#else
#  error "no event loop implementation available"
#endif

#ifdef WAIT_USE_EPOLL

#  include <sys/epoll.h>
#  include <sys/timerfd.h>
typedef struct epoll_event event;

#else

#  include <sys/event.h>
typedef struct kevent event;

// Sets the correct filters in ev array by comparing the existing and desired actions.
// Adds the filter if the desired action is set and the existing action is unset.
// Removes the filter if the desired action is unset and the existing action is set.
#  define UPDATE_FILTER(poll_bit, filter)                                                          \
    do {                                                                                           \
      if ((what & (poll_bit)) && !(sock_info->action & (poll_bit)))                                \
        EV_SET(&ev[count++], sockfd, (filter), EV_ADD, 0, 0, sock_info);                           \
      else if (!(what & (poll_bit)) && (sock_info->action & (poll_bit)))                           \
        EV_SET(&ev[count++], sockfd, (filter), EV_DELETE, 0, 0, sock_info);                        \
    } while (0)

#endif

int  wait_event(int fd, event *events, size_t maxevents, int wait_milliseconds);
int  event_monitor(void);
void ev_monitor_close(WorkerState *wstate);
int  multi_timer_cb(CURLM *multi, long timeout_ms, void *userp);
int  multi_socket_cb(CURL *easy, curl_socket_t sockfd, int what, void *userp, void *socketp);
bool is_timer(event ev);
int  get_curl_event(event ev);
int  get_socket_fd(event ev);

#endif
