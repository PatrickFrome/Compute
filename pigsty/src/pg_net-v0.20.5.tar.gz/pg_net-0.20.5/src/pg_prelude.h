#ifndef PG_PRELUDE_H
#define PG_PRELUDE_H

// pragmas needed to pass compiling with -Wextra
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wsign-compare"

#include <postgres.h>

#include "commands/dbcommands.h"
#include "storage/lmgr.h"
#include <access/hash.h>
#include <access/xact.h>
#include <catalog/namespace.h>
#include <catalog/pg_authid.h>
#include <catalog/pg_extension.h>
#include <catalog/pg_type.h>
#include <commands/defrem.h>
#include <commands/extension.h>
#include <executor/spi.h>
#include <fmgr.h>
#include <miscadmin.h>
#include <nodes/makefuncs.h>
#include <nodes/pg_list.h>
#include <pgstat.h>
#include <postmaster/bgworker.h>
#include <storage/condition_variable.h>
#include <storage/ipc.h>
#include <storage/latch.h>
#include <storage/proc.h>
#include <storage/shmem.h>
#include <tcop/utility.h>
#include <tsearch/ts_locale.h>
#include <utils/acl.h>
#include <utils/builtins.h>
#include <utils/fmgrprotos.h>
#include <utils/guc.h>
#include <utils/guc_tables.h>
#include <utils/hsearch.h>
#include <utils/json.h>
#include <utils/jsonb.h>
#include <utils/lsyscache.h>
#include <utils/memutils.h>
#include <utils/regproc.h>
#include <utils/snapmgr.h>
#include <utils/varlena.h>

#pragma GCC diagnostic pop

#define PG15_GTE (PG_VERSION_NUM >= 150000)
#define PG17_LT (PG_VERSION_NUM < 170000)

#if PG_VERSION_NUM >= 190000
#  define LOG_MIN_MESSAGES *log_min_messages

// clang-format off
#  define PG_SIGNAL_PARAMS                                                                         \
    __attribute__((unused)) int   postgres_signal_arg,\
    __attribute__((unused)) const pg_signal_info *pg_siginfo
// clang-format on
#  define PG_SIGNAL_ARGS postgres_signal_arg, pg_siginfo

#  define PG_JSONB_INIT_STATE(name) JsonbInState name = {0}
#  define PG_JSONB_PUSH(state, action, value) pushJsonbValue(&(state), (action), (value))
#  define PG_JSONB_OBJECT_FINISH(state)                                                            \
    (PG_JSONB_PUSH((state), WJB_END_OBJECT, NULL), JsonbValueToJsonb((state).result))
#else
#  define LOG_MIN_MESSAGES log_min_messages

#  define PG_SIGNAL_PARAMS __attribute__((unused)) int postgres_signal_arg
#  define PG_SIGNAL_ARGS postgres_signal_arg

#  define PG_JSONB_INIT_STATE(name) JsonbParseState *name = NULL
#  define PG_JSONB_PUSH(state, action, value) pushJsonbValue(&(state), (action), (value))
#  define PG_JSONB_OBJECT_FINISH(state)                                                            \
    JsonbValueToJsonb(PG_JSONB_PUSH((state), WJB_END_OBJECT, NULL))
#endif

const char *xact_event_name(XactEvent event);

#if PG17_LT
void destroyStringInfo(StringInfo str);
#endif

#endif /* PG_PRELUDE_H */

#ifdef PG_PRELUDE_IMPL

const char *xact_event_name(XactEvent event) {
  switch (event) {
  case XACT_EVENT_COMMIT             : return "XACT_EVENT_COMMIT";
  case XACT_EVENT_PARALLEL_COMMIT    : return "XACT_EVENT_PARALLEL_COMMIT";
  case XACT_EVENT_ABORT              : return "XACT_EVENT_ABORT";
  case XACT_EVENT_PARALLEL_ABORT     : return "XACT_EVENT_PARALLEL_ABORT";
  case XACT_EVENT_PREPARE            : return "XACT_EVENT_PREPARE";
  case XACT_EVENT_PRE_COMMIT         : return "XACT_EVENT_PRE_COMMIT";
  case XACT_EVENT_PARALLEL_PRE_COMMIT: return "XACT_EVENT_PARALLEL_PRE_COMMIT";
  case XACT_EVENT_PRE_PREPARE        : return "XACT_EVENT_PRE_PREPARE";
  default                            : return "(unknown XactEvent)";
  }
}

#if PG17_LT
// Polyfill for pg < 17
// https://github.com/postgres/postgres/blob/3c4e26a62c31ebe296e3aedb13ac51a7a35103bd/src/common/stringinfo.c#L402-L416
void destroyStringInfo(StringInfo str) {
  Assert(str->maxlen != 0);
  pfree(str->data);
  pfree(str);
}
#endif

#endif /* PG_PRELUDE_IMPL */
