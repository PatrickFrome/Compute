# Executed source verification commands

Application source: ff91a1d8fa2df70e33e35d6267ae4194c32ca7da.
Base: 9d7527683060e314eb1d39fec9ce2304a57103c4.
All paths below are owned isolated workspace paths. No installer command ran.

## Toolchain and frozen dependency provisioning

CWD: /workspace/scratch/4d7321d56cf9/compute-ui-stream4/apps/me2-ui

```bash
BUN_INSTALL_CACHE_DIR=/workspace/scratch/4d7321d56cf9/ui-tooling/bun-cache TMPDIR=/workspace/scratch/4d7321d56cf9/tmp /workspace/scratch/4d7321d56cf9/ui-tooling/bun-linux-x64/bun install --frozen-lockfile --ignore-scripts
node node_modules/typescript/bin/tsc --noEmit --incremental false
node node_modules/eslint/bin/eslint.js .
TMPDIR=/workspace/scratch/4d7321d56cf9/tmp NEXT_TELEMETRY_DISABLED=1 node --test --test-reporter=tap scripts/*.test.mjs src/lib/*.test.mjs
```

The initial generic Node child-test failure in the restricted executor was not counted as a product failure or pass. The reported suites executed in the authorized executor with a real scratch TMPDIR. Bun 1.3.3 archive SHA-256 was checked against the upstream release metadata before execution. Lifecycle scripts and bulk registry audits were not run. Dependency provisioning used the network separately from builds.

## Exact application source worktree and offline build

```bash
git worktree add --detach /workspace/scratch/4d7321d56cf9/compute-ui-source-proof ff91a1d8fa2df70e33e35d6267ae4194c32ca7da
cp -a apps/me2-ui/node_modules /workspace/scratch/4d7321d56cf9/compute-ui-source-proof/apps/me2-ui/node_modules
```

CWD: /workspace/scratch/4d7321d56cf9/compute-ui-source-proof/apps/me2-ui

```bash
NEXT_TELEMETRY_DISABLED=1 ME2_HOSTED_BY_BROWSER=1 ME2_WATCHDOG=off TMPDIR=/workspace/scratch/4d7321d56cf9/tmp unshare --user --map-root-user --net sh -c 'set -eu; ip link set lo up; exec strace -f -qq -e trace=connect,bind,listen -o /workspace/scratch/4d7321d56cf9/ui-evidence/offline-build-1-network.log node node_modules/next/dist/bin/next build'
ME2_BUILD_SHA=ff91a1d8fa2df70e33e35d6267ae4194c32ca7da TMPDIR=/workspace/scratch/4d7321d56cf9/tmp unshare --user --map-root-user --net sh -c 'set -eu; node scripts/postbuild-standalone.mjs; node scripts/pack-me2-ui.mjs'
```

For build 2, only this owned worktree's generated `.next` directory was removed with `fs.rmSync('.next', {recursive:true, force:true})`; the same Next command ran again, changing only the trace filename to offline-build-2-network.log. Both builds returned 0. The reused dist failed later inventory validation: see postpack-2-mutation-observation.json. Its failed observation remains failed. The second standalone was then content-compared while copying to the new ui-source-staging-build2-ff91a1d8 root; unchanged source pack scripts created the fresh payload, and the existing Browser bundle verifier checked it both before and after executor return.

## Focused existing Browser contracts

CWD: the exact source worktree root.

```bash
TMPDIR=/workspace/scratch/4d7321d56cf9/tmp node --test --test-reporter=tap apps/metaengine-browser/test/me2-ui-content-integrity.test.mjs apps/metaengine-browser/test/me2-ui-runtime-integrity.test.mjs apps/metaengine-browser/test/me2-ui-loopback-host.test.mjs apps/metaengine-browser/test/me2-ui-local-profile-outbound-guard.test.mjs apps/metaengine-browser/test/client-runtime-resource.test.mjs apps/metaengine-browser/test/r93-primary-ui-resilience.test.mjs apps/metaengine-browser/test/client-goal-journal.test.mjs
```

## Final readonly source renderer probe

The outer command used `TMPDIR=/workspace/scratch/4d7321d56cf9/tmp unshare --user --map-root-user --mount --net sh -c ...`. Inside that private namespace:

```bash
set -eu
mount --make-rprivate /
mount --bind /workspace/scratch/4d7321d56cf9/ui-source-staging-build2-ff91a1d8/me2-ui-dist /workspace/scratch/4d7321d56cf9/ui-source-staging-build2-ff91a1d8/me2-ui-dist
mount -o remount,bind,ro /workspace/scratch/4d7321d56cf9/ui-source-staging-build2-ff91a1d8/me2-ui-dist
ip link set lo up
node -e 'try { require("fs").writeFileSync("/workspace/scratch/4d7321d56cf9/ui-source-staging-build2-ff91a1d8/me2-ui-dist/__readonly_probe__", "x", {flag:"wx"}); throw new Error("readonly_probe_unexpected_success"); } catch(e) { if(e.code!=="EROFS") throw e; console.log("READONLY_WRITE_PROBE", e.code); }'
exec strace -f -qq -e trace=connect,bind,listen,sendto,sendmsg,execve,clone,clone3,fork,vfork -e raw=sendto,sendmsg -o /workspace/scratch/4d7321d56cf9/ui-evidence/runtime-final-network.log node /workspace/scratch/4d7321d56cf9/compute-ui-stream4/apps/me2-ui/scripts/ui-source-acceptance.mjs --root /workspace/scratch/4d7321d56cf9/ui-source-staging-build2-ff91a1d8/me2-ui-dist --expected-sha ff91a1d8fa2df70e33e35d6267ae4194c32ca7da --evidence-dir /workspace/scratch/4d7321d56cf9/ui-evidence/source-runtime-final --chromium /workspace/scratch/4d7321d56cf9/ui-tooling/chrome-linux64/chrome --playwright-module /opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs
```

Raw sendto/sendmsg formatting records syscall activity without publishing payload. The initial writable and first readonly runs used the saved ui-source-acceptance-used.mjs; the final run used ui-source-acceptance-final.mjs with the strict shutdown guard and self hash. The reports bind their original bundle identities. Fixture bridge observations never stand for an actual Owner.

## Coordinator-owned expected gate failure

```bash
TMPDIR=/workspace/scratch/4d7321d56cf9/tmp EXPECTED_SHA=ff91a1d8fa2df70e33e35d6267ae4194c32ca7da node --test --test-concurrency=1 --test-reporter=tap infra/client-state-runtime/client-critical-closure.test.mjs
```

16 PASS / 1 FAIL / 0 SKIP: current source seal for me2-shell.tsx is stale after the actual repair. This test and the shared seal were retained. The workflow executes this guard before package reservation or physical build. Coordinator integration/reseal is required.
