"""Review-authored inert model checks; never fetch/extract/execute a package."""
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path

EVIDENCE = Path(__file__).resolve().parent
SCRIPTS = Path(os.environ.get('METAENGINE_CIPD_SCRIPT_ROOT',
    '/workspace/metaengine-source/Compute/apps/metaengine-browser/scripts'))
spec = importlib.util.spec_from_file_location('root_cipd_payload', SCRIPTS / 'custom-electron-cipd-payload.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
fixtures = json.loads((EVIDENCE / 'inert-descriptor-fixtures.json').read_bytes())
checks = []
for case in fixtures['cases']:
    data = base64.b64decode(case['archive_base64'], validate=True)
    result = module.inspect_declared_archive(data, fixtures['package_name'], case['synthetic_instance_id'])
    assert result['disposition'] == 'HOLD' and result['authority_effect'] is False
    assert result['member_count'] == 2 and result['archive_extracted'] is False
    assert result['package_code_executed'] is False
    checks.append({'case': case['case'], 'archive_sha256': result['archive_sha256'],
                   'member_inventory_sha256': result['member_inventory_sha256'],
                   'generic_declaration_only': True, 'disposition': 'HOLD'})
(EVIDENCE / 'root-independent-descriptor-checks.json').write_text(json.dumps({
    'cases': checks, 'pass': len(checks),
    'payload_module_sha256': hashlib.sha256((SCRIPTS / 'custom-electron-cipd-payload.py').read_bytes()).hexdigest(),
    'scope': 'INERT_DECLARED_FORMAT_MODELS_NOT_REAL_PACKAGE_VERIFICATION'}, indent=2) + '\n')
data = base64.b64decode(fixtures['cases'][0]['archive_base64'])
(EVIDENCE / 'root-inert-archive.zip').write_bytes(data)
electron = (EVIDENCE / 'electron-DEPS.raw').read_bytes()
chromium = (EVIDENCE / 'chromium-DEPS.raw').read_bytes()
policy = module.request_policy()
selected = [row for row in policy.derive_requests(electron, chromium)['requests']
            if row['selection'] == 'SELECTED']
rejections = []
for row in selected:
    expected = ('full_archive_sha256_disagreement' if row['reference_kind'] == 'SHA256_INSTANCE'
                else 'source_selected_direct_sha256_instance_required')
    try:
        module.verify_source_archive(electron, chromium,
            (row['owner'], row['path'], row['package_index']), data)
    except ValueError as error:
        assert expected in str(error), (expected, str(error))
        rejections.append({'path': row['path'], 'package_index': row['package_index'],
            'package_name': row['package_name'], 'synthetic_archive_rejected': True, 'reason': str(error)})
    else:
        raise AssertionError('synthetic archive accepted for fixed source request')
assert len(rejections) == 33
(EVIDENCE / 'root-all-selected-source-negatives.json').write_text(json.dumps({
    'checks': rejections, 'pass': len(rejections), 'actual_payload_proofs': 0, 'network_used': False,
    'payload_module_sha256': hashlib.sha256((SCRIPTS / 'custom-electron-cipd-payload.py').read_bytes()).hexdigest()
}, indent=2) + '\n')
print(json.dumps({'inert_descriptor_models_pass': len(checks),
    'fixed_source_rejections_pass': len(rejections), 'actual_payloads_verified': 0}))
