#!/usr/bin/env python3
"""Independent fixed-source CIPD model probes. No upstream source execution."""
import base64
from collections import Counter
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import socket
import subprocess
import tempfile
import unittest
from unittest import mock
import urllib.request

ROOT = Path('/workspace/metaengine-source/Compute')
EVIDENCE = Path('/workspace/metaengine-cipd-evidence')
SOURCE = ROOT / 'apps/metaengine-browser/scripts/custom-electron-cipd-policy.py'
SPEC = importlib.util.spec_from_file_location('independent_cipd_policy', SOURCE)
POLICY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(POLICY)
ELECTRON = Path('/workspace/metaengine-next-evidence/upstream/electron-DEPS').read_bytes()
CHROMIUM = Path('/workspace/metaengine-next-evidence/upstream/chromium-DEPS').read_bytes()
PACKET = Path('/workspace/metaengine-deps-evidence/chromium-tree-objects')
VERSION_RECORDS = json.loads((EVIDENCE / 'version-files/source-manifest.json').read_text())
BLOBS = {row['blob_sha1']: (EVIDENCE / 'version-files' / row['path']).read_bytes() for row in VERSION_RECORDS}
INPUTS = {'chromium_tree_objects': PACKET, 'version_file_blobs': BLOBS}
GN = ('chromium', 'src/buildtools/win', 0)
DIRECT = ('chromium', 'src/content/test/data/gpu/meet_effects_videos', 0)


class IndependentCipdTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.plan = POLICY.derive_requests(ELECTRON, CHROMIUM, **INPUTS)

    def test_all_fixed_source_positions_and_selections_match_independent_inventory(self):
        expected = json.loads((EVIDENCE / 'independent-cipd-shape-expectations.json').read_text())
        positions = [(row['owner'], row['path'], index, row['selection'], package['package'])
                     for row in expected['rows'] for index, package in enumerate(row['packages'])]
        observed = [(row['owner'], row['path'], row['package_index'], row['selection'], row['source_package'])
                    for row in self.plan['requests']]
        self.assertEqual(observed, positions)
        self.assertEqual(len(observed), 150)
        self.assertEqual(self.plan['summary']['package_selection'], {'SELECTED': 33, 'EXCLUDED': 115, 'UNRESOLVED': 2})
        for name in ('authority_effect', 'selection_qualified', 'source_closure_qualified', 'client_executed', 'network_used'):
            self.assertIs(self.plan[name], False)
        self.assertEqual(self.plan['disposition'], 'HOLD')

    def test_raw_source_hashes_cannot_be_replaced_with_modified_declarations(self):
        for electron, chromium in ((ELECTRON + b'\n', CHROMIUM), (ELECTRON, CHROMIUM + b'\n')):
            with self.assertRaisesRegex(ValueError, 'fixed_deps_bytes_mismatch'):
                POLICY.derive_requests(electron, chromium, **INPUTS)

    def test_every_version_digest_and_resolution_request_matches_its_source_position(self):
        expected = json.loads((EVIDENCE / 'independent-cipd-shape-expectations.json').read_text())
        files = json.loads((EVIDENCE / 'independent-version-file-verification.json').read_text())
        version_files = {row['path']: row['instance_id'] for row in files['files']}
        observed = {(row['owner'], row['path'], row['package_index']): row for row in self.plan['requests']}
        selected_kinds, resolution_bodies = [], []
        for dependency in expected['rows']:
            for index, package in enumerate(dependency['packages']):
                row = observed[dependency['owner'], dependency['path'], index]
                version = package.get('version') or version_files[package['version_file']]
                self.assertEqual(row['source_version'], version)
                name = package['package'].replace('${{platform}}', 'windows-amd64').replace('${{arch}}', 'amd64').replace('${{os}}', 'windows')
                self.assertEqual(row['package_name'], name)
                direct, payload_digest = None, None
                if re.fullmatch('[0-9a-f]{40}', version):
                    reference_kind, direct = 'LEGACY_SHA1_INSTANCE', version
                else:
                    try:
                        decoded = base64.b64decode(version, altchars=b'-_', validate=True)
                    except (ValueError, base64.binascii.Error):
                        decoded = b''
                    if len(decoded) == 33 and decoded[-1] == 2 and base64.urlsafe_b64encode(decoded).decode() == version:
                        reference_kind, direct, payload_digest = 'SHA256_INSTANCE', version, decoded[:-1].hex()
                    else:
                        reference_kind = 'SYMBOLIC_SELECTOR'
                self.assertEqual(row['reference_kind'], reference_kind)
                self.assertEqual(row['instance_id'], direct)
                self.assertEqual(row['payload_sha256'], payload_digest)
                if row['selection'] == 'SELECTED': selected_kinds.append(reference_kind)
                if row['selection'] == 'SELECTED' and reference_kind == 'SYMBOLIC_SELECTOR':
                    body = {'package': name, 'version': version}
                    self.assertEqual(row['resolution_request'], {'method': 'POST', 'url': POLICY.RESOLVE_URL, 'body': body})
                    resolution_bodies.append(json.dumps(body, sort_keys=True))
                else:
                    self.assertIsNone(row['resolution_request'])
        self.assertEqual(Counter(selected_kinds), {'SHA256_INSTANCE': 11, 'SYMBOLIC_SELECTOR': 22})
        self.assertEqual(len(resolution_bodies), 22)
        self.assertEqual(len(set(resolution_bodies)), 21)

    def test_declared_two_phase_template_and_fixed_names(self):
        self.assertEqual(POLICY.declared_source_format('tools/${{platform}}'), 'tools/${platform}')
        self.assertEqual(POLICY.expand_cipd_template('tools/${platform}'), 'tools/windows-amd64')
        self.assertEqual(POLICY.expand_cipd_template('tools/${os}/${arch}'), 'tools/windows/amd64')
        self.assertEqual(POLICY.expand_cipd_template('tools/${arch=amd64,arm64}'), 'tools/amd64')
        self.assertIsNone(POLICY.expand_cipd_template('tools/${os=linux,mac}'))
        selected = {row['path']: row for row in self.plan['requests'] if row['selection'] == 'SELECTED'}
        self.assertEqual(selected['src/third_party/typescript/linux-amd64/src']['package_name'],
                         'chromium/third_party/typescript/linux-amd64')
        self.assertEqual(selected['src/third_party/apache-windows-arm64']['package_name'],
                         'infra/3pp/tools/httpd-php/windows-arm64')
        self.assertIn('src/third_party/updater/chrome_win_x86/cipd', selected)
        self.assertEqual(self.plan['profile']['cipd_template_values'],
                         {'os': 'windows', 'arch': 'amd64', 'platform': 'windows-amd64'})
        self.assertIs(self.plan['profile']['actual_cipd_executable_bound'], False)

    def test_bad_templates_do_not_hide_behind_a_skipping_branch(self):
        for template in ('tools/${os=linux}/${unknown}', 'tools/${platform.__class__}',
                         'tools/${arch[0]}', 'tools/${platform!r}', 'tools/${platform',
                         'tools/${platform}/../escape', 'tools/${os=}', 'tools/$leftover'):
            with self.subTest(template=template), self.assertRaises(ValueError):
                POLICY.expand_cipd_template(template)
        for raw in ('tools/${platform}', 'tools/{unknown}', 'tools/${{platform}'):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                POLICY.declared_source_format(raw)

    def test_dots_only_package_components_are_rejected(self):
        for name in ('.', '..', '...', '....', 'pkg/.../leaf', '.../leaf',
                     'pkg/....', 'pkg/' + '.' * 256 + '/leaf'):
            with self.subTest(name=name), self.assertRaises(ValueError):
                POLICY.expand_cipd_template(name)
        for name in ('pkg/a...b/leaf', 'pkg/.hidden/leaf', 'pkg/..a/leaf'):
            with self.subTest(valid_name=name):
                self.assertEqual(POLICY.expand_cipd_template(name), name)

    def test_selected_only_positional_selector_rejects_unknown_excluded_and_aliases(self):
        self.assertEqual(POLICY.get_source_request(ELECTRON, CHROMIUM, GN, **INPUTS)['package_name'], 'gn/gn/windows-amd64')
        bad = [('chromium', 'src/third_party/swift-format', 0),
               ('chromium', 'src/third_party/swift-toolchain', 0),
               ('chromium', 'src/chrome/android/orderfiles/arm', 0),
               ('electron', GN[1], 0), ('chromium', GN[1], 1),
               ('chromium', 'src/buildtools/Win', 0), ('chromium', GN[1], True),
               ('chromium', GN[1], '0'), ('chromium', GN[1], -1),
               ('chromium', '../src/buildtools/win', 0)]
        for selector in bad:
            with self.subTest(selector=selector), self.assertRaises(ValueError):
                POLICY.get_source_request(ELECTRON, CHROMIUM, selector, **INPUTS)

    def test_actual_version_files_are_source_bound_but_all_excluded(self):
        expected = json.loads((EVIDENCE / 'independent-version-file-verification.json').read_text())
        files = {row['path']: row for row in expected['files']}
        rows = [row for row in self.plan['requests'] if 'version_file' in row]
        self.assertEqual(len(rows), 4)
        for row in rows:
            proof = row['version_file']; independent = files[proof['path']]
            self.assertEqual(proof['blob_sha1'], independent['git_blob'])
            self.assertEqual(proof['sha256'], independent['sha256'])
            self.assertEqual(row['source_version'], independent['instance_id'])
            self.assertEqual(row['payload_sha256'], independent['digest_hex'])
            self.assertEqual(row['selection'], 'EXCLUDED')
            self.assertIsNone(row['resolution_request'])

    def test_swapped_changed_extra_or_unproven_version_blob_inputs_refuse(self):
        first, second = list(BLOBS)[:2]
        changed = dict(BLOBS); changed[first] = changed[first] + b'\n'
        swapped = dict(BLOBS); swapped[first] = BLOBS[second]
        extra = dict(BLOBS); extra['0' * 40] = b'unknown'
        for blobs in (changed, swapped, extra):
            with self.subTest(blobs=list(blobs)), self.assertRaises(ValueError):
                POLICY.derive_requests(ELECTRON, CHROMIUM, chromium_tree_objects=PACKET, version_file_blobs=blobs)
        with self.assertRaisesRegex(ValueError, 'source_blob_key_not_in_fixed_version_files'):
            POLICY.derive_requests(ELECTRON, CHROMIUM, version_file_blobs=BLOBS)
        trees = POLICY.FixedChromiumTrees(PACKET)
        for path in ('../chrome/build/android-arm.orderfile.txt', '/chrome/build/android-arm.orderfile.txt',
                     'chrome\\build\\android-arm.orderfile.txt', 'src/chrome/build/android-arm.orderfile.txt'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                trees.blob(path)

    def test_bad_or_aliased_merkle_packet_refuses(self):
        with tempfile.TemporaryDirectory(prefix='cipd-merkle-refusal-') as temporary:
            directory = Path(temporary)
            (directory / (POLICY.DEPS.CHROMIUM_TREE + '.tree')).write_bytes(b'')
            with self.assertRaisesRegex(ValueError, 'source_tree_hash_mismatch'):
                POLICY.derive_requests(ELECTRON, CHROMIUM, chromium_tree_objects=directory, version_file_blobs=BLOBS)
            alias = directory / 'alias'; alias.symlink_to(PACKET, target_is_directory=True)
            with self.assertRaisesRegex(ValueError, 'canonical_tree_packet_directory_required'):
                POLICY.FixedChromiumTrees(alias)

    def test_instance_encoding_digest_and_symbolic_prefixes_are_distinct(self):
        digest = bytes(range(32)); instance = base64.urlsafe_b64encode(digest + b'\x02').decode()
        reference = POLICY.classify_reference(instance)
        self.assertEqual(reference['reference_kind'], 'SHA256_INSTANCE')
        self.assertEqual(reference['payload_sha256'], digest.hex())
        self.assertEqual(POLICY.classify_reference('a' * 40)['reference_kind'], 'LEGACY_SHA1_INSTANCE')
        for selector in ('git_revision:' + 'a' * 40, 'version:' + instance,
                         base64.urlsafe_b64encode(digest + b'\x03').decode(), digest.hex(), 'A' * 40):
            with self.subTest(selector=selector):
                value = POLICY.classify_reference(selector)
                self.assertEqual(value['reference_kind'], 'SYMBOLIC_SELECTOR')
                self.assertIsNone(value['instance_id']); self.assertIsNone(value['payload_sha256'])

    def test_forged_resolution_never_becomes_source_pin(self):
        response = {'package': 'gn/gn/windows-amd64', 'instance': {'hashAlgo': 'SHA256', 'hexDigest': '0' * 64}}
        observed = POLICY.inspect_resolution_response(ELECTRON, CHROMIUM, GN, json.dumps(response).encode(), **INPUTS)
        self.assertEqual(observed['origin'], 'CALLER_SUPPLIED_UNAUTHENTICATED_JSON')
        self.assertEqual(observed['disposition'], 'HOLD')
        self.assertIs(observed['selector_binding_qualified'], False)
        self.assertIs(observed['authority_effect'], False)
        self.assertIsNone(observed['source_instance_id'])
        self.assertIsNone(POLICY.get_source_request(ELECTRON, CHROMIUM, GN, **INPUTS)['instance_id'])
        for mutation in ('package', 'authority', 'algorithm', 'digest'):
            changed = copy.deepcopy(response)
            if mutation == 'package': changed['package'] = 'gn/gn/mac-amd64'
            elif mutation == 'authority': changed['authority_effect'] = True
            elif mutation == 'algorithm': changed['instance']['hashAlgo'] = 'SHA1'
            else: changed['instance']['hexDigest'] = '0' * 63
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                POLICY.inspect_resolution_response(ELECTRON, CHROMIUM, GN, json.dumps(changed).encode(), **INPUTS)
        duplicate = b'{"package":"wrong","package":"gn/gn/windows-amd64","instance":{"hashAlgo":"SHA256","hexDigest":"' + b'0' * 64 + b'"}}'
        with self.assertRaisesRegex(ValueError, 'resolution_duplicate_json_key'):
            POLICY.inspect_resolution_response(ELECTRON, CHROMIUM, GN, duplicate, **INPUTS)

    def test_response_cannot_replace_a_direct_source_digest(self):
        direct = POLICY.get_source_request(ELECTRON, CHROMIUM, DIRECT, **INPUTS)
        response = {'package': direct['package_name'], 'instance': {'hashAlgo': 'SHA256', 'hexDigest': direct['payload_sha256']}}
        observed = POLICY.inspect_resolution_response(ELECTRON, CHROMIUM, DIRECT, json.dumps(response).encode(), **INPUTS)
        self.assertEqual(observed['source_instance_id'], direct['instance_id'])
        self.assertIs(observed['selector_binding_qualified'], False)
        response['instance']['hexDigest'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'resolution_conflicts_with_direct_source_instance'):
            POLICY.inspect_resolution_response(ELECTRON, CHROMIUM, DIRECT, json.dumps(response).encode(), **INPUTS)

    def test_profile_selection_flags_digest_and_resolution_plan_edits_refuse(self):
        for mutation in ('platform', 'qualification', 'selection', 'digest', 'resolution', 'blockers'):
            changed = copy.deepcopy(self.plan)
            if mutation == 'platform': changed['profile']['cipd_template_values']['platform'] = 'linux-amd64'
            elif mutation == 'qualification': changed['source_closure_qualified'] = True
            elif mutation == 'selection': changed['requests'][0]['selection'] = 'SELECTED'
            elif mutation == 'digest': changed['requests'][0]['payload_sha256'] = '0' * 64
            elif mutation == 'resolution': changed['requests'][0]['resolution_evidence'] = {'verified': True}
            else: changed['blockers'] = []
            with self.subTest(mutation=mutation), self.assertRaisesRegex(ValueError, 'derived_plan_mismatch'):
                POLICY.verify_derived_plan(changed, ELECTRON, CHROMIUM, **INPUTS)

    def test_recomputation_and_observation_use_no_network_or_subprocess(self):
        with mock.patch.object(socket, 'socket', side_effect=AssertionError('network prohibited')), \
                mock.patch.object(urllib.request, 'urlopen', side_effect=AssertionError('network prohibited')), \
                mock.patch.object(subprocess, 'Popen', side_effect=AssertionError('subprocess prohibited')):
            result = POLICY.derive_requests(ELECTRON, CHROMIUM, **INPUTS)
            self.assertEqual(result, self.plan)
            self.assertEqual(POLICY.verify_derived_plan(result, ELECTRON, CHROMIUM, **INPUTS), result)


if __name__ == '__main__':
    unittest.main(verbosity=2)
