"""Independent self-authored inert byte probes; no Go/service payload parity.

Only the project's new pure data verifier and our own fixture generator execute.
No downloaded source, ZIP member, hook, installer, or tool code executes.
"""
from pathlib import Path
import base64
import binascii
import hashlib
import importlib.util
import json
import struct
import sys
import zlib

ROOT = Path('/workspace/metaengine-cipd-evidence')
APP = Path('/workspace/metaengine-source/Compute/apps/metaengine-browser')
PACKAGE = 'metaengine/review/inert'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


payload = module('independent_payload_verifier', APP / 'scripts/custom-electron-cipd-payload.py')
models = module('independent_descriptor_models', ROOT / 'inert-descriptor-fixtures.py')


def iid(content):
    return base64.urlsafe_b64encode(hashlib.sha256(content).digest() + b'\x02').decode('ascii')


def deflate(data):
    encoder = zlib.compressobj(wbits=-15)
    return encoder.compress(data) + encoder.flush()


def archive(rows=None, *, package=PACKAGE, manifest=None, method=0, descriptor=None):
    # An independent byte writer, deliberately unconstrained for negative data.
    rows = list(rows if rows is not None else [(b'inert.bin', b'inert bytes', {})])
    if manifest is None:
        manifest = {'format_version': '1.1', 'package_name': package}
    if not isinstance(manifest, bytes):
        manifest = json.dumps(manifest, separators=(',', ':')).encode('utf-8')
    rows.append((b'.cipdpkg/manifest.json', manifest, {}))
    local, central = bytearray(), bytearray()
    for name, data, options in rows:
        name = name.encode('ascii') if isinstance(name, str) else name
        compression = options.get('method', method)
        body = options.get('body', deflate(data) if compression == 8 else data)
        style = options.get('descriptor', descriptor)
        flags = options.get('flags', 8 if style else 0)
        size = options.get('size', len(data))
        compressed_size = options.get('compressed_size', len(body))
        crc = options.get('crc', binascii.crc32(data) & 0xffffffff)
        extra = options.get('extra', b'')
        local_name = options.get('local_name', name)
        local_extra = options.get('local_extra', extra)
        position = len(local)
        local.extend(struct.pack('<IHHHHHIIIHH', 0x04034b50, 20,
            options.get('local_flags', flags), options.get('local_method', compression), 0, 0,
            0 if flags & 8 else crc, 0 if flags & 8 else compressed_size,
            0 if flags & 8 else size, len(local_name), len(local_extra)))
        local.extend(local_name + local_extra + body)
        if style:
            local.extend(options.get('descriptor_bytes',
                (b'PK\x07\x08' if style == 'signed' else b'') + struct.pack('<III', crc, compressed_size, size)))
        local.extend(options.get('gap', b''))
        mode = options.get('mode', 0o100400)
        attributes = options.get('attributes', 0 if mode & 0o200 else 1)
        central.extend(struct.pack('<IHHHHHHIIIHHHHHII', 0x02014b50,
            options.get('creator', 0x0314), options.get('required', 20), flags, compression,
            0, 0, crc, compressed_size, size, len(name), len(extra), 0, 0, 0,
            (mode << 16) | attributes, options.get('local_offset', position)))
        central.extend(name + extra)
    return bytes(local + central + struct.pack('<IHHHHIIH', 0x06054b50, 0, 0,
        len(rows), len(rows), len(central), len(local), 0))


results = []


def positive(name, content, *, package=PACKAGE, member_body=None):
    try:
        report = payload.inspect_declared_archive(content, package, iid(content))
        assert report['disposition'] == 'HOLD' and report['authority_effect'] is False
        assert report['archive_extracted'] is False and report['package_code_executed'] is False
        assert report['physical_readback'] == 'NOT_RUN'
        assert report['scope'] == 'DECLARED_SHA256_INSTANCE_ARCHIVE_BYTES_ONLY'
        assert report['archive_sha256'] == hashlib.sha256(content).hexdigest()
        assert 'SOURCE_REQUEST_BINDING_NOT_DERIVED' in report['missing']
        if member_body is not None:
            row = next(row for row in report['members'] if row['path'] == 'inert.bin')
            assert row['size_bytes'] == len(member_body)
            assert row['sha256'] == hashlib.sha256(member_body).hexdigest()
        results.append({'case': name, 'passed': True, 'outcome': 'HOLD',
            'archive_sha256': report['archive_sha256'], 'member_count': report['member_count']})
        return report
    except Exception as error:
        results.append({'case': name, 'passed': False, 'unexpected_error': repr(error)})


def negative(name, content, expected, *, package=PACKAGE, expected_iid=None):
    try:
        payload.inspect_declared_archive(content, package, expected_iid or iid(content))
    except ValueError as error:
        results.append({'case': name, 'passed': expected in str(error), 'outcome': 'REJECT', 'error': str(error)})
    except Exception as error:
        results.append({'case': name, 'passed': False, 'unexpected_error': repr(error)})
    else:
        results.append({'case': name, 'passed': False, 'unexpected_accept': True})


for fixture in models.fixtures():
    positive('descriptor_model_' + fixture['case'], base64.b64decode(fixture['archive_base64']))

for length in (0, 1, 65535, 65536, 65537, 131072, 131073, 262144):
    for method in (0, 8):
        for descriptor in ('signed', 'unsigned'):
            data = b'a' * length
            positive(f'stream_repeated_{length}_{method}_{descriptor}',
                archive([(b'inert.bin', data, {})], method=method, descriptor=descriptor), member_body=data)
for length in (65537, 131073):
    data = hashlib.shake_256(b'independent deterministic inert bytes').digest(length)
    positive(f'stream_incompressible_{length}', archive([(b'inert.bin', data, {})], method=8,
        descriptor='signed'), member_body=data)

valid = archive()
for name in ('...', 'metaengine/.../inert', 'metaengine/..../inert', 'metaengine/../inert', '/metaengine', 'metaengine//inert'):
    negative('canonical_package_' + name, archive(package=name), 'package_name_not_canonical', package=name)
negative('embedded_dots_only_package', archive(package='metaengine/.../inert'), 'package_name_not_canonical')
negative('embedded_wrong_package', valid, 'embedded_package_name_disagreement', package='metaengine/review/other')
negative('changed_full_zip_keeps_old_iid', valid + b'\x00', 'full_archive_sha256_disagreement', expected_iid=iid(valid))
negative('changed_full_zip_redeclared_iid_still_rejects_trailer', valid + b'\x00', 'end_record_not_exact')
for tag in ('version:1.2.3', 'latest', 'a' * 40):
    negative('symbolic_or_legacy_' + tag, valid,
        'legacy_sha1_instance_unsupported' if len(tag) == 40 else 'strong_sha256_instance_required', expected_iid=tag)
negative('unknown_hash_algorithm', valid, 'instance_algorithm_unsupported',
    expected_iid=base64.urlsafe_b64encode(hashlib.sha256(valid).digest() + b'\x03').decode())

for name in (b'a\0hidden', b'../escape', b'a/../escape', b'/rooted', b'C:/drive', b'a\\back',
        b'file:ads', b'AUX .txt', b'CONIN$', b'CONOUT$.log', b'NUL.log', b'LPT9', b'end.', b'end ', b'\xff'):
    negative('unsafe_raw_path_' + name.hex(), archive([(name, b'inert', {})]), 'member_path_')
for names in ((b'same', b'same'), (b'Same', b'same'), (b'Dir/a', b'dir/b'), (b'file', b'file/child')):
    try:
        payload.inspect_declared_archive(archive([(name, b'inert', {}) for name in names]), PACKAGE,
            iid(archive([(name, b'inert', {}) for name in names])))
    except ValueError as error:
        results.append({'case': 'namespace_' + repr(names), 'passed': any(expected in str(error)
            for expected in ('duplicate_or_case_alias', 'parent_component_case_alias', 'file_directory_prefix')),
            'outcome': 'REJECT', 'error': str(error)})
    else:
        results.append({'case': 'namespace_' + repr(names), 'passed': False, 'unexpected_accept': True})

for label, patch, expected in (
    ('symlink_mode', {'mode': 0o120400}, 'member_mode_or_attributes'),
    ('reparse_attributes', {'attributes': 0x401}, 'member_mode_or_attributes'),
    ('readonly_disagreement', {'mode': 0o100600, 'attributes': 1}, 'readonly_mode_disagreement'),
    ('raw_local_name_mismatch', {'local_name': b'inert.bin\0tail'}, 'local_central_header_disagreement'),
    ('flags_disagreement', {'local_flags': 0x800}, 'local_central_header_disagreement'),
    ('encrypted', {'flags': 1}, 'encrypted_member_unsupported'),
    ('unsupported_compression', {'method': 99}, 'compression_unsupported'),
    ('zip64_extra', {'extra': struct.pack('<HH', 1, 0)}, 'zip64_unsupported'),
    ('unicode_alias_extra', {'extra': struct.pack('<HH', 0x7075, 0)}, 'extra_field_unsupported'),
    ('hidden_gap', {'gap': b'opaque'}, 'local_sizes_or_unlisted_bytes'),
    ('overlapping_body', {'compressed_size': 0xffff}, 'member_span_overlapping'),
    ('crc_recompute', {'crc': 7}, 'member_crc_disagreement'),
    ('inflation_exceeds_declared_size', {'method': 8, 'body': deflate(b'a' * 131073), 'size': 1}, 'uncompressed_size_disagreement'),
    ('deflate_trailing_second_stream', {'method': 8, 'body': deflate(b'inert') + deflate(b'hidden')}, 'deflate_trailing_bytes'),
    ('descriptor_wrong_crc', {'descriptor': 'signed', 'descriptor_bytes': b'PK\x07\x08' + b'\x00' * 12}, 'data_descriptor_disagreement'),
):
    negative(label, archive([(b'inert.bin', b'inert', patch)]), expected)
for name in (b'.cipd/state', b'.CIPDPKG/manifest.json', b'.cipdpkg/hook.py'):
    negative('reserved_namespace_' + name.decode(), archive([(name, b'inert', {})]), 'reserved_service_member_unsupported')
negative('duplicate_manifest_json_key', archive(manifest=b'{"format_version":"1.1","package_name":"x","package_name":"y"}'), 'manifest_duplicate_json_key')
negative('deployed_manifest_files_not_archive_member_list', archive(manifest={
    'format_version': '1.1', 'package_name': PACKAGE, 'files': []}), 'manifest_fields_unsupported')
negative('generated_file_collision', archive(manifest={
    'format_version': '1.1', 'package_name': PACKAGE, 'version_file': 'inert.bin'}), 'duplicate_or_case_alias_member')
generated = positive('generated_file_separate_hold', archive(manifest={
    'format_version': '1.1', 'package_name': PACKAGE, 'version_file': 'metadata/version.json'}))
if generated is not None:
    assert generated['generated_deployment_outputs'][0]['is_zip_member'] is False
    assert generated['generated_deployment_outputs'][0]['disposition'] == 'HOLD'
    assert 'GENERATED_DEPLOYMENT_OUTPUT_CLOSURE_NOT_QUALIFIED' in generated['missing']
for value in (bytearray(valid), memoryview(valid)):
    negative('mutable_or_non_bytes_' + type(value).__name__, value, 'archive_type_or_size_limit', expected_iid=iid(valid))

report = {'scope': 'INDEPENDENT_INERT_BYTE_MODELS_ONLY_NOT_GO_OR_SERVICE_PACKAGES',
    'archive_extracted': False, 'downloaded_code_executed': False, 'actual_service_payload': False,
    'production_pin_binding': False, 'authority_effect': False,
    'source_sha256': hashlib.sha256((APP / 'scripts/custom-electron-cipd-payload.py').read_bytes()).hexdigest(),
    'fixture_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'cases': results, 'case_count': len(results), 'passed': sum(row['passed'] for row in results),
    'failed': sum(not row['passed'] for row in results)}
(ROOT / 'independent-payload-probe-results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'cases'}, indent=2))
for row in results:
    if not row['passed']:
        print(json.dumps(row))
sys.exit(1 if report['failed'] else 0)
