"""Self-authored ZIP byte models, not Go-produced or service package evidence."""
from pathlib import Path
import base64
import binascii
import hashlib
import json
import struct
import zlib

PACKAGE_NAME = 'metaengine/review/inert'


def archive_bytes(method, signed, mode):
    manifest = json.dumps({'format_version': '1.1', 'package_name': PACKAGE_NAME}, indent=2).encode()
    entries = [('bin/inert.bin', b'inert nonexecutable fixture data\n', mode),
               ('.cipdpkg/manifest.json', manifest, 0o400)]
    local, central = bytearray(), bytearray()
    for name, raw, perms in entries:
        encoded = name.encode('ascii')
        if method == 8:
            compressor = zlib.compressobj(wbits=-15)
            compressed = compressor.compress(raw) + compressor.flush()
        else:
            compressed = raw
        crc = binascii.crc32(raw) & 0xffffffff
        offset = len(local)
        # Go-shaped normalized attrs and zero DOS timestamps. This model is
        # constructed from the format specification, never by running Go code.
        external = ((0o100000 | perms) << 16) | (0 if perms & 0o200 else 1)
        local += struct.pack('<IHHHHHIIIHH', 0x04034b50, 20, 8, method, 0, 0,
                             0, 0, 0, len(encoded), 0)
        local += encoded + compressed
        if signed:
            local += struct.pack('<I', 0x08074b50)
        local += struct.pack('<III', crc, len(compressed), len(raw))
        central += struct.pack('<IHHHHHHIIIHHHHHII', 0x02014b50, (3 << 8) | 20,
                               20, 8, method, 0, 0, crc, len(compressed), len(raw),
                               len(encoded), 0, 0, 0, 0, external, offset)
        central += encoded
    return bytes(local + central + struct.pack('<IHHHHIIH', 0x06054b50, 0, 0,
                 len(entries), len(entries), len(central), len(local), 0))


def fixtures():
    result = []
    for method in (0, 8):
        for signed in (False, True):
            for mode in (0o400, 0o500):
                data = archive_bytes(method, signed, mode)
                digest = hashlib.sha256(data).digest()
                result.append({'case': f'method_{method}_descriptor_{"signed" if signed else "unsigned"}_mode_{mode:o}',
                    'method': method, 'signed_descriptor': signed, 'permission_mode': oct(mode),
                    'archive_base64': base64.b64encode(data).decode(),
                    'archive_sha256': digest.hex(),
                    'synthetic_instance_id': base64.urlsafe_b64encode(digest + b'\x02').decode()})
    return result


if __name__ == '__main__':
    report = {'scope': 'SELF_AUTHORED_INERT_ZIP_FORMAT_MODELS_NOT_REAL_PACKAGES',
        'package_name': PACKAGE_NAME, 'cases': fixtures(), 'go_executed': False,
        'actual_service_payload': False, 'production_pin_binding': False,
        'payload_code_executed': False, 'authority_effect': False}
    path = Path(__file__).with_name('inert-descriptor-fixtures.json')
    path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'scope': report['scope'], 'cases': len(report['cases']), 'output': str(path)}))
