// Source-only fixture generator authored for this review. Standard library only.
// It writes inert bytes; it never imports LUCI or executes an archive member.
package main

import (
	"archive/zip"
	"os"
)

func main() {
	if len(os.Args) != 2 { panic("one new output filename required") }
	f, err := os.OpenFile(os.Args[1], os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil { panic(err) }
	w := zip.NewWriter(f)
	rows := []struct{name, data string; method uint16; mode os.FileMode}{
		{".cipdpkg/manifest.json", "{\"format_version\":\"1.1\",\"package_name\":\"test/source-only/windows-amd64\",\"install_mode\":\"copy\",\"version_file\":\"versions/component.json\"}", zip.Deflate, 0400},
		{"data/inert.txt", "inert test bytes; no executable content\n", zip.Deflate, 0400},
		{"bin/inert.dat", "inert test bytes with executable mode metadata only\n", zip.Store, 0500},
	}
	for _, row := range rows {
		h := zip.FileHeader{Name:row.name, Method:row.method}
		h.SetMode(row.mode)
		out, err := w.CreateHeader(&h)
		if err != nil { panic(err) }
		if _, err = out.Write([]byte(row.data)); err != nil { panic(err) }
	}
	if err = w.Close(); err != nil { panic(err) }
	if err = f.Close(); err != nil { panic(err) }
}
