#!/usr/bin/env python3
"""Bounded source-only late-helper audit using new disposable Git fixtures."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from unittest import mock

ROOT = Path('/workspace/metaengine-source/Compute')


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'apps/metaengine-browser/scripts' / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


policy = load('independent_late_deps', 'custom-electron-deps-policy.py')
builder = load('independent_late_builder', 'custom-electron-source-build.py')
real_popen = subprocess.Popen
real_git = shutil.which('git')
calls = []


def git(repository, *args):
    return subprocess.check_output([real_git, '-c', 'core.hooksPath=' + os.devnull,
        '-c', 'commit.gpgsign=false', '-C', str(repository), *args],
        env={**os.environ, 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': os.devnull},
        stderr=subprocess.DEVNULL)


def snapshot(directory):
    return {str(path.relative_to(directory)): (path.stat().st_mode,
            hashlib.sha256(path.read_bytes()).hexdigest())
            for path in sorted(directory.rglob('*')) if path.is_file()}


def observed_popen(arguments, *args, **kwargs):
    assert isinstance(arguments, list) and arguments[0] == 'git', arguments
    index = arguments.index('-C')
    command = arguments[index + 2:]
    assert command[0] in {'config', 'rev-parse', 'for-each-ref', 'cat-file'}, command
    if command[0] == 'config':
        assert command == ['config', '--local', '--no-includes', '--name-only', '--list'], command
    env = kwargs['env']
    assert env['GIT_NO_LAZY_FETCH'] == env['GIT_NO_REPLACE_OBJECTS'] == '1'
    assert env['GIT_OPTIONAL_LOCKS'] == '0' and env['GIT_CONFIG_GLOBAL'] == os.devnull
    calls.append(command)
    return real_popen(arguments, *args, **kwargs)


outcomes = []
with tempfile.TemporaryDirectory(prefix='independent-fixed-git-input-') as temporary:
    root = Path(temporary)
    sources, trees, repositories = {}, {}, {}
    content = b"vars = {}; deps = {}; hooks = []; recursedeps = []\n"
    for owner in ('electron', 'chromium'):
        repository = root / owner
        repository.mkdir()
        git(repository, 'init', '--quiet')
        (repository / 'DEPS').write_bytes(content)
        (repository / 'unexecuted-source.py').write_text("raise RuntimeError('source must never execute')\n")
        git(repository, 'add', 'DEPS', 'unexecuted-source.py')
        git(repository, '-c', 'user.name=Inert Source Review',
            '-c', 'user.email=inert@example.invalid', 'commit', '-qm', 'inert fixture')
        commit = git(repository, 'rev-parse', 'HEAD').decode().strip()
        tree = git(repository, 'rev-parse', 'HEAD^{tree}').decode().strip()
        sources[owner] = {'commit': commit,
            'blob_sha1': hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest(),
            'sha256': hashlib.sha256(content).hexdigest()}
        trees[owner], repositories[owner] = tree, repository

    with mock.patch.dict(policy.SOURCES, sources), mock.patch.dict(policy.SOURCE_TREES, trees), \
            mock.patch.object(policy, 'CHROMIUM_TREE', trees['chromium']):
        before = snapshot(root)
        with mock.patch.object(subprocess, 'Popen', side_effect=observed_popen):
            result = policy.derive_from_git(repositories['electron'], repositories['chromium'])
        assert result['disposition'] == 'HOLD'
        assert result['gitlink_packet_checked'] is True
        assert all(result[name] is False for name in
            ('selection_qualified', 'source_closure_qualified', 'authority_effect'))
        assert snapshot(root) == before
        outcomes.append('fixed-object helper uses read-only Git, hardened env and leaves all fixture files unchanged')

        saved_commit = policy.SOURCES['electron']['commit']
        policy.SOURCES['electron']['commit'] = 'f' * 40
        try:
            with mock.patch.object(subprocess, 'Popen', side_effect=observed_popen):
                try:
                    policy.derive_from_git(repositories['electron'], repositories['chromium'])
                    raise AssertionError('missing fixed commit was accepted')
                except ValueError as error:
                    assert 'required_object_unavailable' in str(error), error
        finally:
            policy.SOURCES['electron']['commit'] = saved_commit
        assert snapshot(root) == before
        outcomes.append('missing fixed commit refuses without fetch or repository changes')

        saved_blob = policy.SOURCES['electron']['blob_sha1']
        policy.SOURCES['electron']['blob_sha1'] = '0' * 40
        try:
            with mock.patch.object(subprocess, 'Popen', side_effect=observed_popen):
                try:
                    policy.derive_from_git(repositories['electron'], repositories['chromium'])
                    raise AssertionError('wrong DEPS tree membership was accepted')
                except ValueError as error:
                    assert 'fixed_deps_tree_membership_mismatch' in str(error), error
        finally:
            policy.SOURCES['electron']['blob_sha1'] = saved_blob
        assert snapshot(root) == before
        outcomes.append('wrong fixed DEPS blob membership refuses before source execution or repository changes')

        git(repositories['electron'], 'config', 'remote.origin.promisor', 'true')
        guarded_before = snapshot(root)
        calls.clear()
        with mock.patch.object(subprocess, 'Popen', side_effect=observed_popen):
            try:
                policy.derive_from_git(repositories['electron'], repositories['chromium'])
                raise AssertionError('promisor configuration was accepted')
            except ValueError as error:
                assert 'partial_clone_or_external_filter_forbidden' in str(error), error
        assert not any(command[0] == 'cat-file' for command in calls)
        assert snapshot(root) == guarded_before
        outcomes.append('promisor configuration refuses before object access, no fetch or repository changes')

with mock.patch.object(builder, 'load_deps_policy') as loader:
    try:
        builder.require_gclient_dependency_closure()
        raise AssertionError('missing source context was accepted')
    except builder.BuildError as error:
        assert str(error) == 'custom_electron_gclient_deps_cipd_hook_closure_unavailable:source_inputs_unavailable'
    loader.assert_not_called()
outcomes.append('no-context closure refuses before policy loading')

for blockers in ([], ['IMMUTABLE_INTERPRETER_UNAVAILABLE']):
    candidate = mock.Mock()
    candidate.derive_from_git.return_value = {
        'blockers': blockers, 'selection_qualified': True,
        'source_closure_qualified': True, 'authority_effect': True}
    with mock.patch.object(builder, 'load_deps_policy', return_value=candidate):
        try:
            builder.require_gclient_dependency_closure(Path('/inert/source'))
            raise AssertionError('candidate flags or empty blocker list bypassed HOLD')
        except builder.BuildError as error:
            assert str(error).startswith('custom_electron_gclient_deps_cipd_hook_closure_unavailable:')
    candidate.derive_from_git.assert_called_once_with(Path('/inert/source/electron'), Path('/inert/source'))
outcomes.append('qualification bits and even an empty blocker list cannot turn wrapper HOLD into success')

print(json.dumps({'status': 'PASS', 'checks': len(outcomes), 'outcomes': outcomes,
                  'upstream_source_executed': False, 'source_repository_mutated': False}, indent=2))
