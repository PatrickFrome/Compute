#!/usr/bin/env python3
"""Independent source-only probes; no upstream DEPS execution or side effects."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path('/workspace/metaengine-source/Compute')
EVIDENCE = Path('/workspace/metaengine-deps-evidence')
SOURCE = ROOT / 'apps/metaengine-browser/scripts/custom-electron-deps-policy.py'
SPEC = importlib.util.spec_from_file_location('independent_deps_policy', SOURCE)
POLICY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(POLICY)
ELECTRON = Path('/workspace/metaengine-next-evidence/upstream/electron-DEPS').read_bytes()
CHROMIUM = Path('/workspace/metaengine-next-evidence/upstream/chromium-DEPS').read_bytes()


class IndependentDepsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = POLICY.derive_manifest(ELECTRON, CHROMIUM,
            EVIDENCE / 'chromium-tree-objects')

    def test_exact_sources_and_global_hold(self):
        result = self.manifest
        self.assertEqual(result['scope'], 'PINNED_TOP_LEVEL_DEPS_ONLY')
        self.assertEqual(result['disposition'], 'HOLD')
        for name in ('selection_qualified', 'source_closure_qualified', 'authority_effect'):
            self.assertIs(result[name], False)
        self.assertEqual(result['summary']['dependency_kinds'], {'git': 278, 'cipd': 144, 'gcs': 30})
        self.assertEqual(result['summary']['hook_count'], 77)
        self.assertEqual(result['summary']['recursion_count'], 10)
        self.assertTrue(all(hook['executed'] is False for hook in result['hooks']))

    def test_sources_require_both_hashes(self):
        POLICY.pinned_bytes(ELECTRON, 'electron')
        with self.assertRaisesRegex(ValueError, 'fixed_deps_bytes_mismatch'):
            POLICY.pinned_bytes(ELECTRON + b'\n', 'electron')
        with self.assertRaisesRegex(ValueError, 'fixed_deps_bytes_mismatch'):
            POLICY.pinned_bytes(CHROMIUM.replace(b'False', b'True ', 1), 'chromium')

    def test_unsupported_source_never_executes(self):
        with tempfile.TemporaryDirectory(prefix='deps-static-only-') as temporary:
            marker = Path(temporary) / 'executed'
            payload = f"__import__('pathlib').Path({str(marker)!r}).write_text('executed')"
            sources = [
                'import pathlib\nvars = {}',
                f'vars = {{"x": {payload}}}',
                'vars = {"x": [value for value in []]}',
                'vars = {"x": f"{1}"}',
                'vars = {"x": ().__class__}',
                'vars = {**{}}',
                'vars = {"x": Var("foo", "bar")}',
                'vars = {"x": Var(1)}',
                'vars = {"x": Str("foo", unsafe=True)}',
            ]
            for content in sources:
                with self.subTest(content=content), self.assertRaises(ValueError):
                    POLICY.StaticDeps(content.encode(), 'inert_fixture')
            self.assertFalse(marker.exists())

    def test_all_condition_branches_validated(self):
        document = POLICY.StaticDeps(b'vars = {}', 'inert_fixture')
        for condition in ('False and __import__("os")', 'True or ().__class__',
                          'False and x[0]', 'True or [x for x in []]'):
            with self.subTest(condition=condition), self.assertRaises(ValueError):
                document.condition(condition)

    def test_duplicate_fields_and_keys_refused(self):
        for content in ('vars = {}\nvars = {}', 'vars = {"x": True, "x": False}',
                        'deps = {"src/a": "a", "src/a": "b"}', 'vars = deps = {}'):
            with self.subTest(content=content), self.assertRaises(ValueError):
                POLICY.StaticDeps(content.encode(), 'inert_fixture')

    def test_unknown_and_cycles_fail_closed(self):
        document = POLICY.StaticDeps(b"vars = {'a': 'b', 'b': 'a'}", 'inert_fixture')
        self.assertIsInstance(document.condition('unknown'), POLICY.Unknown)
        self.assertEqual(POLICY.selection(document.condition('unknown')), 'UNRESOLVED')
        self.assertEqual(POLICY.selection(document.condition('unknown and False')), 'EXCLUDED')
        self.assertEqual(POLICY.selection(document.condition('unknown or True')), 'SELECTED')
        with self.assertRaisesRegex(ValueError, 'condition_variable_cycle'):
            document.condition('a')

    def test_str_wrapper_and_no_truthy_string_boolean(self):
        document = POLICY.StaticDeps(b"vars = {'a': Str('False'), 'b': 'False'}", 'inert_fixture')
        self.assertIs(document.condition('b'), False)
        self.assertIs(document.condition('a == "False"'), True)
        with self.assertRaisesRegex(ValueError, 'condition_not_boolean'):
            document.condition('a')

    def test_parent_conflicts_are_explicit(self):
        expected = ['checkout_clang_tidy', 'checkout_openxr', 'generate_location_tags']
        self.assertEqual(self.manifest['parent_variable_conflicts'], expected)
        rows = [row for row in self.manifest['dependencies'] if row['path'] == 'src/third_party/openxr/src']
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['selection'], 'UNRESOLVED')
        self.assertIn('PARENT_VARIABLE_PRECEDENCE:checkout_openxr', rows[0]['condition_result']['unresolved'])

    def test_string_comparison_ambiguity_has_truthful_reason(self):
        document = POLICY.StaticDeps(b"vars = {'checkout_configuration': 'default'}", 'inert_fixture')
        value = document.condition('checkout_configuration != "small"')
        self.assertIsInstance(value, POLICY.Unknown)
        self.assertEqual(value.reasons, {'STRING_VAR_SEMANTICS_UNKNOWN:checkout_configuration'})
        rows = [row for row in self.manifest['dependencies']
                if row['path'].startswith(('src/third_party/jetstream/', 'src/third_party/speedometer/'))]
        self.assertEqual(len(rows), 7)
        for row in rows:
            self.assertNotIn('CONDITION_VAR:default', row['condition_result'].get('unresolved', []))

    def test_substitution_stays_literal_data(self):
        document = POLICY.StaticDeps(b'vars = {}', 'inert_fixture')
        document.context['s'] = POLICY.LiteralString('x" != "x" or True or "x')
        self.assertIs(document.condition('"{s}" == "never"'), False)
        for unsafe in ('"{s.__class__}" == "x"', '"{s[0]}" == "x"', '"{s!r}" == "x"'):
            with self.subTest(unsafe=unsafe), self.assertRaises(ValueError):
                document.condition(unsafe)

    def test_semantic_declarations_and_pinned_aliases_retained(self):
        declarations = {row['owner']: row for row in self.manifest['declarations']}
        self.assertEqual(declarations['electron']['semantic_fields']['gclient_gn_args_from'], 'src')
        fields = declarations['chromium']['semantic_fields']
        self.assertEqual(fields['gclient_gn_args_file'], 'src/build/config/gclient_args.gni')
        self.assertIn('generate_location_tags', fields['gclient_gn_args'])
        self.assertIn('allowed_hosts', fields)
        variables = {row['name']: row for row in declarations['chromium']['variables']}
        self.assertEqual(variables['non_git_source']['value'], 'True')
        self.assertIs(variables['non_git_source']['literal_str'], False)
        self.assertIs(variables['cros_boards']['literal_str'], True)
        expected = {'src': 'dd78960ccd8a03a2fe1f629543d27783885b78e9',
                    'src/third_party/electron_node': 'f14cd3aa7bf9ca8df2cc5b8bb14beb0f335b1d93'}
        for row in self.manifest['dependencies']:
            if row['owner'] == 'electron' and row['path'] in expected:
                self.assertEqual(row['revision'], expected[row['path']])
                self.assertEqual(row['revision_source'], 'FIXED_INDEPENDENT_ALIAS_EVIDENCE')

    def test_bare_mac_name_is_not_guessed(self):
        rows = [row for row in self.manifest['dependencies']
                if row['path'] in ('src/third_party/swift-format', 'src/third_party/swift-toolchain')]
        self.assertEqual(len(rows), 2)
        for row in rows:
            self.assertEqual(row['selection'], 'UNRESOLVED')
            self.assertIn('CONDITION_VAR:mac', row['condition_result']['unresolved'])

    def test_gcs_parent_condition_preserved(self):
        rows = [row for row in self.manifest['dependencies'] if row['kind'] == 'gcs']
        self.assertEqual(sum(len(row['objects']) for row in rows), 85)
        for row in rows:
            for obj in row['objects']:
                self.assertIn('condition_result', obj)
                if row['selection'] == 'EXCLUDED':
                    self.assertEqual(obj['selection'], 'EXCLUDED')
        self.assertEqual(sum('condition' in obj for row in rows for obj in row['objects']), 30)

    def test_cipd_version_file_has_no_invented_version(self):
        packages = [package for row in self.manifest['dependencies'] if row['kind'] == 'cipd'
                    for package in row['packages']]
        self.assertEqual(len(packages), 150)
        version_files = [package for package in packages if 'version_file' in package]
        self.assertEqual(len(version_files), 4)
        self.assertTrue(all('version' not in package for package in version_files))
        for row in self.manifest['dependencies']:
            if row['kind'] == 'cipd':
                self.assertIn('CIPD_PAYLOAD_MEMBERSHIP_UNVERIFIED', row['missing'])

    def test_fixed_root_gitlink_packet_refuses_corruption(self):
        with tempfile.TemporaryDirectory(prefix='deps-tree-refusal-') as temporary:
            (Path(temporary) / (POLICY.CHROMIUM_TREE + '.tree')).write_bytes(b'')
            with self.assertRaisesRegex(ValueError, 'tree_packet_hash_mismatch'):
                POLICY.gitlinks_from_trees(temporary)

    def test_hashed_gitlinks_match_independent_inventory(self):
        independent = json.loads((EVIDENCE / 'root-independent-gitlinks.json').read_text())
        links = POLICY.gitlinks_from_trees(EVIDENCE / 'chromium-tree-objects')
        self.assertEqual(len(links), 270)
        self.assertEqual({'src/' + key: value for key, value in links.items()}, independent['gitlinks'])
        for row in self.manifest['dependencies']:
            if row['owner'] == 'chromium' and row['kind'] == 'git' and row['revision_source'] == 'HASHED_CHROMIUM_GITLINK':
                self.assertEqual(row['revision'], independent['gitlinks'][row['path']])

    def test_derived_manifest_tampering_refused(self):
        baseline = POLICY.derive_manifest(ELECTRON, CHROMIUM)
        content = POLICY.canonical_bytes(baseline)
        self.assertEqual(POLICY.verify_derived_manifest(content, ELECTRON, CHROMIUM), hashlib.sha256(content).hexdigest())
        for mutation in ('authority', 'delete_hook', 'delete_dependency', 'selection'):
            changed = copy.deepcopy(baseline)
            if mutation == 'authority':
                changed['authority_effect'] = True
            elif mutation == 'delete_hook':
                changed['hooks'].pop()
            elif mutation == 'delete_dependency':
                changed['dependencies'].pop()
            else:
                changed['dependencies'][0]['selection'] = 'EXCLUDED'
            with self.subTest(mutation=mutation), self.assertRaisesRegex(ValueError, 'derived_manifest_bytes_mismatch'):
                POLICY.verify_derived_manifest(POLICY.canonical_bytes(changed), ELECTRON, CHROMIUM)


if __name__ == '__main__':
    unittest.main(verbosity=2)
