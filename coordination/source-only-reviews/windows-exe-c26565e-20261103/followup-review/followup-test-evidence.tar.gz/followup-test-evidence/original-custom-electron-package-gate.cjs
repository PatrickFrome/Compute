'use strict';
// BUILD-HOST byte gate for the custom Electron static-peer-v1 runtime.
//
// This module is not a release signature, creation authority or runtime
// admission input. It binds a staged custom runtime distribution to:
//   - the pinned upstream identity recorded in the repository pins,
//   - the pinned interface patch and the complete staged native source tree,
//   - a full file inventory with SHA256/size agreement, and
//   - PE-level markers of the Guardian original-main static composition.
// A stock electron-builder artifact (the public npm Electron distribution)
// has none of these and fails closed. Existing stock qualifiers are not
// bypassed or reinterpreted by this gate.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const APP = path.resolve(__dirname, '..');
const SCHEMA = 'metaengine.custom-electron-build-host-bytes.v1';
const DIST_REL = 'native-dist/custom-electron';
const RECEIPT_REL = 'native-dist/custom-electron-build-host-receipt.json';
const STATIC_BINDING = Buffer.from('electron_browser_guardian_original_main\0');
const ORIGIN = {
  electron: 'c542df1ecbc2c2978e8f53f8c7baf602404d166f',
  node: 'f14cd3aa7bf9ca8df2cc5b8bb14beb0f335b1d93',
  v8: 'a11d960c1c22c067ff898ceb4a8e4e0687014d41',
  boringssl: '572a4c68475d284b34675f45ddbb9c158ef3c2ae',
  chromium_tag: '152.0.7977.167',
};
const GN_TARGET = '//electron/guardian_original_main/native/electron-original-main:guardian_original_main';

function stop(reason) { throw new Error('custom_electron_package_' + reason); }
function sha(data) { return crypto.createHash('sha256').update(data).digest('hex'); }
function sha256File(file) {
  const digest = crypto.createHash('sha256');
  digest.update(fs.readFileSync(file));
  return digest.digest('hex');
}

function ordinary(root, relative) {
  if (!relative || path.isAbsolute(relative) || relative.split(/[\\/]/).includes('..') || relative.includes('\\')) {
    stop('path_invalid:' + relative);
  }
  const absolute = path.resolve(root, relative);
  const rootAbsolute = path.resolve(root);
  if (!absolute.startsWith(rootAbsolute + path.sep)) stop('path_escape:' + relative);
  let current = rootAbsolute;
  if (fs.lstatSync(current).isSymbolicLink()) stop('symlink:' + relative);
  for (const part of relative.split('/')) {
    if (!part || part === '.') stop('path_invalid:' + relative);
    current = path.join(current, part);
    if (fs.lstatSync(current).isSymbolicLink()) stop('symlink:' + relative);
  }
  if (!fs.lstatSync(absolute).isFile()) stop('not_file:' + relative);
  return absolute;
}

// Digest the executable code section and prove the static Guardian binding
// name is embedded in the image. Byte-level PE parsing only; never executed.
function peExecutableDigest(bytes, label) {
  if (!Buffer.isBuffer(bytes) || bytes.length < 0x100 || bytes.toString('ascii', 0, 2) !== 'MZ') {
    stop('pe_dos_header:' + label);
  }
  const header = bytes.readUInt32LE(0x3c);
  if (header <= 0 || header > bytes.length - 24) stop('pe_header_offset:' + label);
  if (bytes.toString('ascii', header, header + 4) !== 'PE\0\0') stop('pe_signature:' + label);
  if (bytes.readUInt16LE(header + 4) !== 0x8664) stop('pe_arch_not_x64:' + label);
  if (bytes.readUInt16LE(header + 24) !== 0x20b) stop('pe_not_pe32plus:' + label);
  const count = bytes.readUInt16LE(header + 6);
  const optionsSize = bytes.readUInt16LE(header + 20);
  const table = header + 24 + optionsSize;
  if (!count || count > 96 || table > bytes.length - count * 40) stop('pe_sections_invalid:' + label);
  let textDigest = null;
  let bindingFound = false;
  for (let index = 0; index < count; index += 1) {
    const entry = table + index * 40;
    const name = bytes.toString('ascii', entry, entry + 8).replace(/\0+$/, '');
    const size = bytes.readUInt32LE(entry + 16);
    const begin = bytes.readUInt32LE(entry + 20);
    if (name !== '.text' && !/^[.A-Za-z0-9_-]+$/.test(name)) stop('pe_section_name_invalid:' + label);
    if (!size || begin > bytes.length || size > bytes.length - begin) stop('pe_section_bounds:' + label);
    const raw = bytes.subarray(begin, begin + size);
    if (name === '.text') {
      if (textDigest !== null) stop('pe_text_duplicate:' + label);
      textDigest = sha(raw);
    }
    if (raw.includes(STATIC_BINDING)) bindingFound = true;
  }
  if (textDigest === null) stop('pe_text_missing:' + label);
  if (!bindingFound) stop('pe_static_original_main_binding_not_present:' + label);
  return textDigest;
}

// Mirror of the builder's staged native/ source manifest. The argument is the
// native/ directory itself.
function nativeSourceManifest(nativeDirectory) {
  const native = nativeDirectory;
  if (!fs.lstatSync(native).isDirectory()) stop('native_source_directory_missing');
  const manifest = {};
  const walk = (directory, relative) => {
    for (const item of fs.readdirSync(directory, { withFileTypes: true })) {
      const name = relative ? relative + '/' + item.name : item.name;
      const absolute = path.join(directory, item.name);
      if (item.isSymbolicLink()) stop('native_source_symlink:' + name);
      if (item.isDirectory()) {
        if (item.name === '__pycache__') continue;
        walk(absolute, name);
      } else if (item.isFile()) {
        if (item.name.endsWith('.pyc')) continue;
        manifest[name] = sha256File(absolute);
      } else stop('native_source_unexpected_kind:' + name);
    }
  };
  walk(native, '');
  if (!Object.keys(manifest).length) stop('native_source_tree_empty');
  return manifest;
}

function checkDist({ appRoot = APP, dist, receipt, configuration, outputExecutable = null,
  nativeRoot = null }) {
  const root = path.resolve(appRoot);
  if (typeof dist !== 'string' || typeof receipt !== 'string') stop('arguments_invalid');
  const distAbsolute = path.resolve(root, dist);
  const receiptAbsolute = path.resolve(root, receipt);
  const expectedDist = path.join(root, DIST_REL);
  if (distAbsolute.includes(`${path.sep}node_modules${path.sep}`)) stop('stock_node_modules_dist_forbidden');
  if (distAbsolute !== expectedDist) stop('dist_path_drift:' + dist);
  if (receiptAbsolute === path.join(expectedDist, path.basename(receiptAbsolute))
      || receiptAbsolute.startsWith(expectedDist + path.sep)) stop('receipt_must_be_outside_dist');
  const config = configuration || JSON.parse(fs.readFileSync(path.join(root, 'electron-builder.test.json'), 'utf8'));
  if (config.electronDist !== DIST_REL) stop('custom_electron_dist_not_selected');
  if (config.electronVersion !== '44.9.3') stop('custom_electron_version_not_pinned');
  let receiptStat;
  try {
    receiptStat = fs.lstatSync(receiptAbsolute);
  } catch {
    stop('receipt_regular_file_required');
  }
  if (receiptStat.isSymbolicLink() || !receiptStat.isFile()) {
    stop('receipt_regular_file_required');
  }
  let distStat;
  try {
    distStat = fs.lstatSync(distAbsolute);
  } catch {
    stop('distribution_directory_required');
  }
  if (!distStat.isDirectory() || distStat.isSymbolicLink()) stop('distribution_directory_required');
  const evidence = JSON.parse(fs.readFileSync(receiptAbsolute, 'utf8'));
  const native = nativeRoot || path.join(root, 'native');
  const actualManifest = nativeSourceManifest(native);
  if (evidence.schema !== SCHEMA
      || evidence.profile !== 'static-peer-v1'
      || evidence.electron !== '44.9.3' || evidence.node !== '24.22.0'
      || evidence.origin?.electron !== ORIGIN.electron
      || evidence.origin?.node !== ORIGIN.node
      || evidence.origin?.v8 !== ORIGIN.v8
      || evidence.origin?.boringssl !== ORIGIN.boringssl
      || evidence.origin?.chromium_tag !== ORIGIN.chromium_tag
      || evidence.gn_target !== GN_TARGET
      || evidence.interface_patch_sha256 !== sha256File(path.join(native,
        'electron-original-main/electron-44.9.3-original-main-entry.interface.patch'))
      || evidence.pins_file_sha256 !== sha256File(path.join(native,
        'electron-original-main/electron-44.9.3-original-main-entry.pins.json'))
      || evidence.openssl?.version !== '3.5.9'
      || evidence.openssl?.signature_verified !== true
      || evidence.openssl?.boringssl_commit !== ORIGIN.boringssl
      || evidence.authority_effect !== false || evidence.signed !== false
      || evidence.windows_qualified !== false || evidence.runtime_admission_input !== false) {
    stop('build_receipt_contract');
  }
  // The distribution must have been built from THIS repository's native tree.
  const receiptManifest = evidence.native_source_manifest;
  if (!receiptManifest || typeof receiptManifest !== 'object'
      || Array.isArray(receiptManifest)) stop('receipt_native_manifest_invalid');
  const receiptNames = Object.keys(receiptManifest).sort();
  const actualNames = Object.keys(actualManifest).sort();
  if (receiptNames.length !== actualNames.length
      || receiptNames.some((name, index) => name !== actualNames[index]
        || receiptManifest[name] !== actualManifest[name])) {
    stop('native_source_manifest_drift');
  }
  if (!Array.isArray(evidence.files) || evidence.files.length < 2) stop('inventory_missing');
  const inventory = new Map();
  const folded = new Set();
  for (const entry of evidence.files) {
    if (!entry || typeof entry.path !== 'string' || inventory.has(entry.path)
        || folded.has(entry.path.toLowerCase()) || !/^[0-9a-f]{64}$/.test(entry.sha256)
        || !Number.isSafeInteger(entry.bytes) || entry.bytes <= 0) stop('inventory_invalid');
    const content = fs.readFileSync(ordinary(distAbsolute, entry.path));
    if (content.length !== entry.bytes || sha(content) !== entry.sha256) stop('inventory_mutated:' + entry.path);
    inventory.set(entry.path, content);
    folded.add(entry.path.toLowerCase());
  }
  // No unchecked files, aliases or injected DLLs can cross this distribution.
  const found = [];
  const walk = (directory, relative = '') => {
    for (const item of fs.readdirSync(directory, { withFileTypes: true })) {
      if (item.isSymbolicLink()) stop('distribution_symlink:' + item.name);
      const name = relative ? relative + '/' + item.name : item.name;
      if (item.isDirectory()) walk(path.join(directory, item.name), name);
      else if (item.isFile()) found.push(name);
      else stop('distribution_unexpected_kind:' + name);
    }
  };
  walk(distAbsolute);
  if (found.length !== inventory.size || found.some((name) => !inventory.has(name))) {
    stop('distribution_inventory_extra_or_missing');
  }
  const exe = inventory.get('electron.exe');
  if (!exe || exe.length < 1_000_000 || sha(exe) !== evidence.electron_exe_sha256) stop('custom_exe_invalid');
  const code = peExecutableDigest(exe, 'distribution');
  if (outputExecutable !== null) {
    const output = fs.readFileSync(outputExecutable);
    if (output.length < 1_000_000) stop('packaged_exe_too_small');
    if (peExecutableDigest(output, 'packaged') !== code) stop('packaged_exe_code_mismatch');
  }
  return { electron_exe_sha256: sha(exe), pe_text_sha256: code, files: found.length,
    authority_effect: false };
}

// electron-builder hook entry: reject a stock runtime before any staging work
// (beforePack) and re-verify the packaged executable's code identity (afterPack).
function checkBuilderContext(context, { after = false, appRoot = APP, nativeRoot = null } = {}) {
  if (process.platform !== 'win32' || context?.electronPlatformName !== 'win32'
      || String(context.arch) !== '1') {
    // electron-builder's Arch.x64 enum is integer 1.
    stop('win_x64_only');
  }
  const root = context.packager?.projectDir;
  if (!root || path.resolve(root) !== path.resolve(appRoot)) stop('app_root_invalid');
  let outputExecutable = null;
  if (after) {
    const name = context.packager?.appInfo?.productFilename;
    if (!name || /[\\/]/.test(name)) stop('product_exe_name_invalid');
    outputExecutable = path.join(context.appOutDir, name + '.exe');
  }
  return checkDist({
    appRoot: root,
    dist: DIST_REL,
    receipt: RECEIPT_REL,
    configuration: context.packager.config,
    outputExecutable,
    nativeRoot,
  });
}

module.exports = { checkDist, checkBuilderContext, peExecutableDigest, nativeSourceManifest,
  DIST_REL, RECEIPT_REL, SCHEMA };
