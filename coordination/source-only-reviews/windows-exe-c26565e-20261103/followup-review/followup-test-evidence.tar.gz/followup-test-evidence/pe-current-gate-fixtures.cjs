'use strict';
// Independent in-process gate regression. Synthetic PE bytes are read as data;
// no executable or downloaded package code is launched or imported.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const vm = require('node:vm');
const out = __dirname;
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
function loadSnapshot(name) {
  const filename = path.join(out, 'pe-upstream', name);
  const source = fs.readFileSync(filename, 'utf8');
  const module = { exports: {} };
  const allowed = new Map([['node:fs', fs], ['node:path', path], ['node:crypto', crypto]]);
  vm.runInNewContext(source, {
    module, exports: module.exports, Buffer, process,
    __dirname: path.dirname(filename),
    require(id) {
      if (!allowed.has(id)) throw new Error('unexpected_module:' + id);
      return allowed.get(id);
    },
  }, { filename, timeout: 1000 });
  return { gate: module.exports, source_sha256: sha(Buffer.from(source)) };
}
const original = loadSnapshot('reviewed-custom-electron-package-gate.cjs');
const current = loadSnapshot('reviewed-current-custom-electron-package-gate.cjs');
const root = fs.mkdtempSync(path.join(out, 'pe-gate-synthetic-'));
const dist = path.join(root, 'native-dist/custom-electron');
const native = path.join(root, 'native');
fs.mkdirSync(dist, { recursive: true });
fs.mkdirSync(path.join(native, 'electron-original-main'), { recursive: true });
const manifest = {};
for (const name of ['electron-44.9.3-original-main-entry.interface.patch', 'electron-44.9.3-original-main-entry.pins.json']) {
  const rel = 'electron-original-main/' + name;
  const bytes = Buffer.from('synthetic parser fixture, no source/build authority\n' + name);
  fs.writeFileSync(path.join(native, rel), bytes);
  manifest[rel] = sha(bytes);
}
const base = Buffer.alloc(1024 * 1024);
fs.readFileSync(path.join(out, 'pe-negative-fixture-baseline.bin')).copy(base);
fs.writeFileSync(path.join(dist, 'electron.exe'), base);
const data = Buffer.from('synthetic fixture');
fs.writeFileSync(path.join(dist, 'icudtl.dat'), data);
const origin = {
  electron: 'c542df1ecbc2c2978e8f53f8c7baf602404d166f',
  node: 'f14cd3aa7bf9ca8df2cc5b8bb14beb0f335b1d93',
  v8: 'a11d960c1c22c067ff898ceb4a8e4e0687014d41',
  boringssl: '572a4c68475d284b34675f45ddbb9c158ef3c2ae',
  chromium_tag: '152.0.7977.167',
};
const receipt = {
  schema: 'metaengine.custom-electron-build-host-bytes.v1',
  profile: 'static-peer-v1', electron: '44.9.3', node: '24.22.0', origin,
  upstream_checkout_heads: Object.fromEntries(Object.entries(origin).filter(([k]) => k !== 'chromium_tag')),
  gn_target: '//electron/guardian_original_main/native/electron-original-main:guardian_original_main',
  interface_patch_sha256: manifest['electron-original-main/electron-44.9.3-original-main-entry.interface.patch'],
  pins_file_sha256: manifest['electron-original-main/electron-44.9.3-original-main-entry.pins.json'],
  native_source_manifest: manifest,
  openssl: { version: '3.5.9', signature_verified: true, boringssl_commit: origin.boringssl },
  authority_effect: false, signed: false, windows_qualified: false, runtime_admission_input: false,
  files: [
    { path: 'electron.exe', bytes: base.length, sha256: sha(base) },
    { path: 'icudtl.dat', bytes: data.length, sha256: sha(data) },
  ],
  electron_exe_sha256: sha(base),
};
fs.writeFileSync(path.join(root, 'native-dist/custom-electron-build-host-receipt.json'), JSON.stringify(receipt));
const outputExecutable = path.join(root, 'synthetic-packaged.bin');
const args = {
  appRoot: root, dist: 'native-dist/custom-electron',
  receipt: 'native-dist/custom-electron-build-host-receipt.json',
  configuration: { electronDist: 'native-dist/custom-electron', electronVersion: '44.9.3' },
  outputExecutable,
};
const pe = 0x80;
const opt = pe + 24;
const table = opt + 0xf0;
const mutations = [
  ['identical_control', () => {}],
  ['entry_point_changed', b => { b.writeUInt32LE(0x1010, opt + 16); }],
  ['import_directory_changed', b => { b.writeUInt32LE(0x20a0, opt + 120); b.writeUInt32LE(40, opt + 124); }],
  ['tls_directory_changed', b => { b.writeUInt32LE(0x3020, opt + 184); b.writeUInt32LE(40, opt + 188); }],
  ['rdata_permissions_changed_to_rwx', b => { b.writeUInt32LE(0xe0000040, table + 40 + 36); }],
  ['import_name_bytes_changed', b => { b.write('evil.dll\0', 0x6a0); }],
  ['data_section_bytes_changed', b => { b[0x820] ^= 0xff; }],
  ['resource_section_bytes_changed', b => { b[0xa80] ^= 0xff; }],
  ['certificate_directory_changed', b => { b.writeUInt32LE(0xf00, opt + 144); b.writeUInt32LE(0x80, opt + 148); }],
  ['overlay_byte_changed', b => { b[0xe00] = 0x41; }],
  ['overlay_appended', b => Buffer.concat([b, Buffer.from('unchecked-overlay')])],
  ['text_control_changed', b => { b[0x410] ^= 0xff; }],
  ['marker_control_missing', b => { b.fill(0, 0x620, 0x620 + Buffer.byteLength('electron_browser_guardian_original_main\0')); }],
];
const cases = [];
for (const [name, mutate] of mutations) {
  let bytes = Buffer.from(base);
  const replacement = mutate(bytes);
  if (replacement) bytes = replacement;
  fs.writeFileSync(outputExecutable, bytes);
  const results = {};
  for (const [version, loaded] of [['original', original], ['current', current]]) {
    let returnValue = null, error = null;
    try { returnValue = loaded.gate.checkDist(args); }
    catch (e) { error = e.message; }
    results[version] = { accepted: error === null, error, returnValue };
  }
  const isUnchangedTextMutation = !name.endsWith('_control') && !['text_control_changed', 'marker_control_missing'].includes(name);
  const currentDigestIsFullImage = name === 'marker_control_missing' ? null
    : current.gate.peExecutableDigest(bytes, name) === sha(bytes);
  const passed = name === 'identical_control'
    ? results.original.accepted && results.current.accepted && currentDigestIsFullImage
    : isUnchangedTextMutation
      ? results.original.accepted && !results.current.accepted
        && results.current.error === 'custom_electron_package_packaged_exe_transform_unqualified_hold'
        && currentDigestIsFullImage
      : !results.original.accepted && !results.current.accepted;
  cases.push({ name, unchanged_text_mutation: isUnchangedTextMutation,
    full_bytes_equal: bytes.equals(base), sha256: sha(bytes),
    current_digest_matches_full_image_sha256: currentDigestIsFullImage,
    ...results, expectation_passed: Boolean(passed) });
  if (!passed) process.exitCode = 1;
}
const evidence = {
  schema: 'metaengine.review.pe-current-gate-fixtures.v1',
  scope: 'VM-loaded gate snapshots and checkDist against self-authored synthetic byte fixtures; no source/build authority asserted',
  original_source_sha256: original.source_sha256,
  current_source_sha256: current.source_sha256,
  synthetic_fixture_root: root,
  windows_code_executed: false, downloaded_package_code_executed: false,
  cases,
  unsafe_original_acceptances_now_held: cases.filter(c => c.unchanged_text_mutation && c.original.accepted && !c.current.accepted).length,
  all_expectations_passed: cases.every(c => c.expectation_passed),
};
fs.writeFileSync(path.join(out, 'pe-current-gate-fixtures.json'), JSON.stringify(evidence, null, 2) + '\n');
process.stdout.write(JSON.stringify(evidence, null, 2) + '\n');
