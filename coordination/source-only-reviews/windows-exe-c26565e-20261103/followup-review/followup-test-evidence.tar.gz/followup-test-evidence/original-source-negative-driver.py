from pathlib import Path
import importlib.util
import unittest

root = Path('/workspace/metaengine-source/Compute')
evidence = Path('/workspace/metaengine-followup-evidence')
def load(name, path, source_context=None):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    if source_context is not None:
        module.__file__ = str(source_context)
    spec.loader.exec_module(module)
    return module

original = load('original_receipt_source', evidence / 'original-custom-electron-source-build.py',
                root / 'apps/metaengine-browser/scripts/custom-electron-source-build.py')
models = load('followup_models', root / 'apps/metaengine-browser/test/test_custom_electron_source_build.py')
for name in ('APP', 'REPOSITORY', 'NATIVE', 'MOUNT', 'PINS_FILE', 'INTERFACE_PATCH', 'OPENSSL_LOCK', 'OPENSSL_CERTIFICATE'):
    setattr(original, name, getattr(models.builder, name))
models.builder = original
names = ('test_extra_descendant_source_outside_pinned_files_is_refused',
         'test_dirty_tracked_source_at_the_locked_head_is_refused',
         'test_extra_untracked_source_at_the_locked_head_is_refused',
         'test_clean_four_repo_fixture_cannot_supply_missing_chromium_identity')
print('PRE-FIX REPRODUCTION: new refusal regressions run against the staged pre-fix source builder.', flush=True)
print('All repositories/bytes are inert temporary fixtures; no full upstream checkout or binary is built.', flush=True)
suite = unittest.TestSuite(models.CheckoutIdentityTests(name) for name in names)
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
