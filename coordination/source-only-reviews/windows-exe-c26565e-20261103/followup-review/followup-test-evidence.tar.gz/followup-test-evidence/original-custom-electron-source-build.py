#!/usr/bin/env python3
"""Fail-closed Windows source build/staging of the custom Electron runtime.

This is a BUILD-HOST transaction for the pinned Electron 44.9.3 / Node 24.22.0
``static-peer-v1`` runtime, not a runtime capability, signature, installed
environment attestation or release. It never executes the produced Windows PE,
never installs software, never touches services/DB/credentials and never edits
source seals or versions.

Every stage fails closed. On any failure the custom distribution is never
marked complete. Upstream source acquisition (gclient) and Guardian's
independently authenticated OpenSSL producer remain prerequisites of the
caller; this script only re-verifies their pinned bytes.

Verification stages, in order:
  1. local lock/pin consistency (pins.json + Guardian OpenSSL lock)
  2. upstream checkout identity (commits, preimages, patched Node bytes,
     primary source evidence documents)
  3. the existing bounded source-interface checker (patch apply + postimages)
  4. cryptographic prerequisites (pinned OpenSSL archive/signature with the
     existing official GPG certificate verifier; pinned BoringSSL commit)
  5. staging of this repository's complete native/ tree into the disposable
     upstream Electron checkout, then application of the pinned interface patch
  6. GN generation with the documented static-peer-v1 arguments and a real
     ``gn desc`` dependency-graph check of the Guardian source-set
  7. ``ninja`` build of ``electron`` and ``electron:electron_dist_zip``
  8. verification that the dist zip's electron.exe equals the freshly linked
     binary, followed by an atomic, replay-free staging of the distribution
  9. an untrusted build-host byte receipt (never a runtime admission input)
"""

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

APP = Path(__file__).resolve().parents[1]
REPOSITORY = APP.parents[1]
NATIVE = APP / 'native'
MOUNT = NATIVE / 'electron-original-main'
PINS_FILE = MOUNT / 'electron-44.9.3-original-main-entry.pins.json'
INTERFACE_PATCH = MOUNT / 'electron-44.9.3-original-main-entry.interface.patch'
OPENSSL_LOCK = NATIVE / 'openssl' / 'guardian-openssl-source-lock.json'
OPENSSL_CERTIFICATE = NATIVE / 'openssl' / 'openssl-release-public-certificate.asc'
GN_TARGET = '//electron/guardian_original_main/native/electron-original-main:guardian_original_main'
NATIVE_REL = Path('electron/guardian_original_main/native')
GN_ARGS = ('import("//electron/build/args/release.gn") '
           'is_component_build=false target_cpu="x64" use_remoteexec=false')
EXPECTED = {
    'electron_version': '44.9.3',
    'node_version': '24.22.0',
    'electron_commit': 'c542df1ecbc2c2978e8f53f8c7baf602404d166f',
    'node_commit': 'f14cd3aa7bf9ca8df2cc5b8bb14beb0f335b1d93',
    'v8_commit': 'a11d960c1c22c067ff898ceb4a8e4e0687014d41',
    'boringssl_commit': '572a4c68475d284b34675f45ddbb9c158ef3c2ae',
    'chromium_tag': '152.0.7977.167',
    'profile': 'static-peer-v1',
}
# Sources of the GN static source-set. The builder fails if BUILD.gn stops
# naming exactly these translation units (plus its own headers).
GN_SOURCE_SET = {
    'guardian-electron-entry.cpp', 'guardian-electron-entry.hpp',
    'guardian-electron-node-mount.cpp',
    'browser-guardian-connected-peer-napi.cpp', 'browser-guardian-connected-peer.cpp',
    'browser-guardian-installed-namespace.cpp',
    'browser-guardian-original-main-native-host.cpp',
    'browser-guardian-release-signature.cpp',
}
# Files that must exist in the staged native/ tree for the source-set and its
# transitive includes to compile; verified before GN ever runs.
GN_REQUIRED_HEADERS = {
    'browser-guardian-original-main-native-host.hpp', 'browser-guardian-original-main-profile.hpp',
    'browser-guardian-original-main-entry-state.hpp', 'browser-guardian-original-main-entry-protocol.hpp',
    'browser-guardian-connected-peer.hpp', 'browser-guardian-pipe-io-lifetime.hpp',
    'browser-guardian-installed-namespace.hpp', 'browser-guardian-release-signature.hpp',
    'browser-guardian-original-material-channel.hpp', 'browser-guardian-original-material-wire.hpp',
    'browser-guardian-original-material-napi.inc',
}


class BuildError(ValueError):
    """Fail-closed builder refusal; message starts with custom_electron_."""


def fail(reason):
    raise BuildError('custom_electron_' + reason)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def filehash(path):
    return sha256(Path(path).read_bytes())


def ordinary(root, relative):
    """Resolve a regular file under root, refusing symlinks and escapes."""
    rel = Path(relative)
    if rel.is_absolute() or not rel.parts or '..' in rel.parts:
        fail('relative_path_invalid:' + str(relative))
    current = Path(root)
    for part in rel.parts:
        current = current / part
        if current.is_symlink():
            fail('symlink_forbidden:' + str(relative))
    if not current.is_file():
        fail('file_missing:' + str(relative))
    return current


def load_pins():
    pins = json.loads(PINS_FILE.read_text(encoding='utf8'))
    if (pins.get('schema') != 'metaengine.electron-original-main-source-composition.v1'
            or pins.get('electron_version') != EXPECTED['electron_version']
            or pins.get('node_version') != EXPECTED['node_version']
            or pins.get('electron_commit') != EXPECTED['electron_commit']
            or pins.get('node_commit') != EXPECTED['node_commit']
            or pins.get('v8_commit') != EXPECTED['v8_commit']
            or pins.get('boringssl_commit') != EXPECTED['boringssl_commit']
            or pins.get('chromium_tag') != EXPECTED['chromium_tag']
            or pins.get('profile') != EXPECTED['profile']
            or pins.get('binding') != 'electron_browser_guardian_original_main'
            or pins.get('native_entry_abi') != 1):
        fail('source_pins_lock_drift')
    if filehash(INTERFACE_PATCH) != pins['patch_sha256']:
        fail('interface_patch_digest_drift')
    paths = [row['path'] for row in pins['files']]
    if (len(paths) != 3 or set(paths) != {'BUILD.gn', 'shell/app/electron_main_win.cc',
                                          'shell/common/node_bindings.cc'}):
        fail('pins_file_set_invalid')
    return pins


def load_openssl_lock():
    lock = json.loads(OPENSSL_LOCK.read_text(encoding='utf8'))
    if (lock.get('schema') != 'metaengine.guardian-openssl-source-lock.v1'
            or lock.get('openssl', {}).get('version') != '3.5.9'
            or lock.get('configure_args') != ['VC-WIN64A', '--release', 'no-shared', 'no-module',
                                              'no-dso', 'no-engine', 'no-autoload-config', 'no-legacy',
                                              'ASFLAGS=--reproducible']):
        fail('guardian_openssl_lock_drift')
    return lock


def git(root, *arguments):
    if not Path(root).is_dir():
        fail('upstream_checkout_missing:' + Path(root).name)
    result = subprocess.run(['git', '-C', str(root), *arguments], text=True, capture_output=True)
    if result.returncode:
        fail('upstream_git_failed:' + Path(root).name + ':' + ' '.join(arguments))
    return result.stdout.strip()


def git_head(root):
    head = git(root, 'rev-parse', 'HEAD')
    if len(head) != 40 or any(c not in '0123456789abcdef' for c in head):
        fail('upstream_git_head_invalid:' + Path(root).name)
    return head


def commit_is_at_or_after(root, pinned):
    """Electron's gclient hook applies its patch series with ``git am``.

    A correctly provisioned checkout therefore has HEAD equal to the pinned
    commit (before hooks) or a descendant of it (after hooks). The pinned
    content hashes below remain the authoritative gate either way.
    """
    head = git_head(root)
    if head == pinned:
        return head
    ancestor = subprocess.run(['git', '-C', str(root), 'merge-base', '--is-ancestor', pinned, 'HEAD'],
                              capture_output=True)
    if ancestor.returncode != 0:
        fail('upstream_commit_not_pinned_lineage:' + Path(root).name)
    return head


def verify_source_identity(chromium, pins):
    electron = chromium / 'electron'
    node = chromium / 'third_party/electron_node'
    v8 = chromium / 'v8'
    boringssl = chromium / 'third_party/boringssl/src'
    heads = {
        'electron': git_head(electron),
        'node': commit_is_at_or_after(node, EXPECTED['node_commit']),
        'v8': commit_is_at_or_after(v8, EXPECTED['v8_commit']),
        'boringssl': commit_is_at_or_after(boringssl, EXPECTED['boringssl_commit']),
    }
    if heads['electron'] != EXPECTED['electron_commit']:
        fail('electron_commit_drift')
    for row in pins['files']:
        if filehash(ordinary(electron, row['path'])) != row['before_sha256']:
            fail('electron_preimage_drift:' + row['path'])
    # Node is verified by its final patched bytes, because Electron's patch
    # series is committed on top of the pinned upstream commit.
    for row in pins['node_files_after_electron_patches']:
        if filehash(ordinary(node, row['path'])) != row['sha256']:
            fail('patched_node_bytes_drift:' + row['path'])
    # Primary source evidence documents recorded with the pins.
    for row in pins.get('primary_source_evidence', []):
        path = row['path']
        if path.startswith('electron/'):
            candidate = chromium / path
        elif path.startswith('chromium/DEPS'):
            candidate = chromium / 'DEPS'
        elif path.startswith('v8/'):
            candidate = chromium / 'v8' / path[len('v8/'):]
        else:
            continue
        if filehash(ordinary(chromium, candidate.relative_to(chromium))) != row['decoded_file_sha256']:
            fail('primary_source_evidence_drift:' + path)
    official = pins.get('official_headers', {})
    if (official.get('url') != 'https://electronjs.org/headers/v44.9.3/node-v44.9.3-headers.tar.gz'
            or not str(official.get('sha256', '')).startswith('5f75ae1e70e69442c9d23f7d984e8ca2')
            or official.get('bytes') != 349406):
        fail('official_header_pin_drift')
    return heads


def run_interface_checker(chromium, pins):
    """Reuse the repository's bounded checker; do not re-implement its logic."""
    if [row['path'] for row in pins['files']] != ['BUILD.gn', 'shell/app/electron_main_win.cc',
                                                  'shell/common/node_bindings.cc']:
        fail('interface_checker_input_invalid')
    checker = APP / 'scripts/check-guardian-electron-source-interface.py'
    result = subprocess.run([sys.executable, str(checker),
                             '--electron-source', str(chromium / 'electron'),
                             '--node-source', str(chromium / 'third_party/electron_node')],
                            text=True, capture_output=True)
    if result.returncode != 0 or '"status": "PASS"' not in result.stdout:
        fail('existing_interface_checker_rejected:' + result.stdout.strip()[:200])
    return json.loads([line for line in result.stdout.splitlines() if line.startswith('{')][-1])


def verify_cryptographic_prerequisites(chromium, openssl_lock, archive, signature):
    """Pinned OpenSSL bytes plus the existing official GPG verifier.

    Digest agreement alone is never accepted as authentication; the existing
    acquisition module's isolated-keyring GPG verification must succeed with
    the checked-in official public certificate and pinned fingerprints.
    """
    if archive is None or signature is None:
        fail('guardian_openssl_inputs_required')
    pinned = openssl_lock['openssl']
    for path, key in ((archive, 'archive'), (signature, 'signature')):
        spec = pinned[key]
        if (path.name != spec['filename'] or path.stat().st_size != spec['size_bytes']
                or filehash(path) != spec['sha256']):
            fail('guardian_openssl_' + key + '_drift')
    if not OPENSSL_CERTIFICATE.is_file():
        fail('guardian_openssl_certificate_missing')
    gpg = shutil.which('gpg')
    if not gpg:
        fail('guardian_openssl_gpg_unavailable')
    module_path = APP / 'scripts/acquire-guardian-openssl-source.py'
    spec = importlib.util.spec_from_file_location('guardian_existing_openssl_acquirer', module_path)
    acquirer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(acquirer)
    primary = pinned['signing_primary_fingerprint']
    signer = pinned['signing_subkey_fingerprint']
    with tempfile.TemporaryDirectory(prefix='custom-electron-openssl-gpg-') as temporary:
        home = Path(temporary)
        home.chmod(0o700)
        acquirer.import_certificate(home, OPENSSL_CERTIFICATE, primary, signer, gpg_binary=gpg)
        evidence = Path(temporary) / 'evidence'
        evidence.mkdir()
        identity = acquirer.verify_signature(home, archive, signature, primary, signer,
                                              evidence, gpg_binary=gpg)
        if (identity['signing_fingerprint'] != signer
                or (evidence / 'gpg-status.txt').read_bytes().count(b'VALIDSIG') != 1):
            fail('guardian_openssl_signature_identity_drift')
    git_head(chromium / 'third_party/boringssl/src')  # lineage pinned in verify_source_identity
    return {'openssl_version': pinned['version'], 'signature_verified': True,
            'boringssl_commit': EXPECTED['boringssl_commit']}


def native_source_manifest():
    """Digest of every file this repository stages into the Electron build."""
    files = {}
    for path in sorted(NATIVE.rglob('*')):
        if (path.is_symlink() or not path.is_file()
                or '__pycache__' in path.parts or path.suffix == '.pyc'):
            continue
        files[path.relative_to(NATIVE).as_posix()] = filehash(path)
    if not files:
        fail('native_source_tree_empty')
    return files


def stage_native_sources(chromium):
    destination = chromium / NATIVE_REL
    if destination.exists():
        fail('native_stage_already_exists_no_retry')
    manifest = native_source_manifest()
    staged = {name for name in manifest if name.startswith('electron-original-main/')
              or name.startswith('browser-guardian-scm/')}
    missing = (GN_SOURCE_SET | GN_REQUIRED_HEADERS) - {
        name.split('/', 1)[1] for name in staged}
    if missing:
        fail('native_stage_required_source_missing:' + ','.join(sorted(missing)))
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(NATIVE, destination, symlinks=False,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    copied = native_source_manifest()
    for name, digest in copied.items():
        if filehash(ordinary(chromium, NATIVE_REL / name)) != digest:
            fail('native_stage_bytes_drift:' + name)
    return manifest


def apply_interface_patch(chromium, pins):
    electron = chromium / 'electron'
    patch = chromium / NATIVE_REL / 'electron-original-main/electron-44.9.3-original-main-entry.interface.patch'
    for arguments in (['--check'], []):
        result = subprocess.run(['git', 'apply', *arguments, str(patch)],
                                cwd=electron, text=True, capture_output=True)
        if result.returncode:
            fail('interface_patch_application_failed:' + result.stderr.strip()[:200])
    for row in pins['files']:
        if filehash(ordinary(electron, row['path'])) != row['after_sha256']:
            fail('electron_postimage_drift:' + row['path'])


def generate_and_check_gn(chromium, out):
    subprocess.run(['gn', 'gen', str(out), '--args=' + GN_ARGS], cwd=chromium,
                   check=True, stdout=subprocess.DEVNULL)

    def desc(label, what):
        return subprocess.check_output(['gn', 'desc', str(out), label, what, '--all'],
                                       cwd=chromium, text=True)
    for label in ('//electron:electron_lib', '//electron:electron_app'):
        if GN_TARGET not in desc(label, 'deps'):
            fail('gn_guardian_target_unreachable:' + label)
    sources = desc(GN_TARGET, 'sources')
    for source in GN_SOURCE_SET:
        if source not in sources:
            fail('gn_source_not_in_graph:' + source)
    deps = desc(GN_TARGET, 'deps')
    for expected in ('//third_party/boringssl', '//third_party/electron_node'):
        if expected not in deps:
            fail('gn_crypto_or_node_dependency_missing:' + expected)


def verified_zip_entries(zip_path):
    """Read the GN-produced dist zip into memory with strict entry checks."""
    entries = {}
    folded = set()
    total = 0
    with zipfile.ZipFile(zip_path) as archive:
        for entry in archive.infolist():
            name = entry.filename.replace('\\', '/')
            if (not name or name.startswith('/') or '\\' in entry.filename
                    or '..' in Path(name).parts or name.endswith('/')):
                fail('dist_zip_path_invalid:' + entry.filename)
            if (entry.external_attr >> 16) & 0o170000 == 0o120000:
                fail('dist_zip_symlink_forbidden')
            if name in entries or name.lower() in folded:
                fail('dist_zip_duplicate:' + name)
            total += entry.file_size
            if len(entries) >= 10000 or total > 5_000_000_000 or entry.file_size > 1_000_000_000:
                fail('dist_zip_entry_oversized')
            entries[name] = archive.read(entry)
            folded.add(name.lower())
    exe = [name for name in entries if name.lower() == 'electron.exe']
    if len(exe) != 1 or len(entries) < 2:
        fail('dist_zip_not_electron_distribution')
    return entries


def build_receipt(heads, pins, openssl, native_manifest, exe_sha256, inventory):
    return {
        'schema': 'metaengine.custom-electron-build-host-bytes.v1',
        'profile': EXPECTED['profile'],
        'electron': EXPECTED['electron_version'],
        'node': EXPECTED['node_version'],
        'origin': {
            'electron': EXPECTED['electron_commit'], 'node': EXPECTED['node_commit'],
            'v8': EXPECTED['v8_commit'], 'boringssl': EXPECTED['boringssl_commit'],
            'chromium_tag': EXPECTED['chromium_tag'],
        },
        # Electron's hooks can commit their patch series on top of the locked
        # upstream revisions. Keep those observed heads as build evidence;
        # origin is the upstream lock identity checked by the package gate.
        'upstream_checkout_heads': dict(heads),
        'interface_patch_sha256': pins['patch_sha256'],
        'pins_file_sha256': filehash(PINS_FILE),
        'openssl': {
            'version': openssl['openssl_version'],
            'signature_verified': openssl['signature_verified'],
            'boringssl_commit': openssl['boringssl_commit'],
        },
        'gn_target': GN_TARGET,
        'gn_args': GN_ARGS,
        'native_source_manifest': native_manifest,
        'electron_exe_sha256': exe_sha256,
        'files': inventory,
        'authority_effect': False, 'signed': False, 'windows_qualified': False,
        'runtime_admission_input': False,
    }


def publish_distribution(dist_zip, linked_exe, destination, receipt_path, heads, pins,
                         openssl, native_manifest):
    if destination.exists() or receipt_path.exists():
        fail('outputs_must_be_new_no_replay')
    entries = verified_zip_entries(dist_zip)
    exe_name = next(name for name in entries if name.lower() == 'electron.exe')
    if filehash(linked_exe) != sha256(entries[exe_name]):
        fail('dist_exe_differs_from_linked_binary')
    if linked_exe.stat().st_size < 1_000_000:
        fail('linked_exe_too_small')
    resolved = destination.resolve()
    if not resolved.is_relative_to(REPOSITORY) or 'node_modules' in resolved.parts:
        fail('distribution_must_be_inside_repository_outside_node_modules')
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix='electron-dist-incomplete-', dir=destination.parent))
    try:
        for name, content in sorted(entries.items()):
            target = temporary / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
        os.replace(temporary, destination)
    except BaseException:
        shutil.rmtree(temporary, ignore_errors=True)
        raise
    inventory = [{'path': name, 'sha256': sha256(data), 'bytes': len(data)}
                 for name, data in sorted(entries.items())]
    receipt = build_receipt(heads, pins, openssl, native_manifest,
                            sha256(entries[exe_name]), inventory)
    if receipt_path.resolve().is_relative_to(destination.resolve()):
        fail('receipt_must_be_outside_distribution')
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    with receipt_path.open('x', encoding='utf8') as output:
        output.write(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--chromium', required=True, type=Path,
                        help='Provisioned pinned Chromium src/ checkout (electron, v8, third_party)')
    parser.add_argument('--openssl-archive', required=True, type=Path,
                        help='Authenticated pinned OpenSSL 3.5.9 source archive')
    parser.add_argument('--openssl-signature', required=True, type=Path,
                        help='Authenticated pinned OpenSSL 3.5.9 detached signature')
    parser.add_argument('--out', required=True, type=Path,
                        help='NEW GN output directory under the Chromium checkout (out/GuardianRelease)')
    parser.add_argument('--dist-zip', required=True, type=Path,
                        help='Exact electron:electron_dist_zip output path inside --out')
    parser.add_argument('--dist', required=True, type=Path,
                        help='NEW custom distribution directory inside this repository')
    parser.add_argument('--receipt', required=True, type=Path,
                        help='NEW untrusted build-host byte receipt path (outside the distribution)')
    args = parser.parse_args()
    try:
        if sys.platform != 'win32' or os.environ.get('PROCESSOR_ARCHITECTURE', '').lower() not in ('amd64', 'x64'):
            fail('native_windows_x64_source_build_required')
        chromium = args.chromium.resolve(strict=True)
        if args.out.exists() or args.dist.exists() or args.receipt.exists():
            fail('outputs_must_be_new')
        if args.out.parent.resolve() != (chromium / 'out').resolve():
            fail('gn_output_must_be_in_chromium_out')
        if not args.dist_zip.resolve().is_relative_to(args.out.resolve()) or args.dist_zip.is_symlink():
            fail('dist_zip_not_from_fresh_gn_output')
        pins = load_pins()
        openssl_lock = load_openssl_lock()
        heads = verify_source_identity(chromium, pins)
        checker = run_interface_checker(chromium, pins)
        openssl = verify_cryptographic_prerequisites(chromium, openssl_lock,
                                                     args.openssl_archive.resolve(strict=True),
                                                     args.openssl_signature.resolve(strict=True))
        manifest = stage_native_sources(chromium)
        apply_interface_patch(chromium, pins)
        generate_and_check_gn(chromium, args.out)
        subprocess.run(['ninja', '-C', str(args.out), 'electron', 'electron:electron_dist_zip'],
                       cwd=chromium, check=True)
        linked = ordinary(args.out, 'electron.exe')
        receipt = publish_distribution(args.dist_zip, linked, args.dist, args.receipt,
                                       heads, pins, openssl, manifest)
        print(json.dumps({'status': 'PASS', 'scope': 'SOURCE_BUILD_AND_BYTE_STAGE_ONLY',
                          'electron_exe_sha256': receipt['electron_exe_sha256'],
                          'interface_checker': checker['status'],
                          'files': len(receipt['files'])}))
    except (BuildError, OSError, ValueError, KeyError,
            subprocess.CalledProcessError, zipfile.BadZipFile) as error:
        parser.exit(1, 'FAIL ' + str(error) + '\n')


if __name__ == '__main__':
    main()
