// Review-only inert regression probe; never imported by production or packaging.
// All runtime filesystem, process, network and PostgreSQL facets are doubles.
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import test from 'node:test';
import {fileURLToPath, pathToFileURL} from 'node:url';
import vm from 'node:vm';
import {fixedWindowsNativeReadEnvironment} from '../metaengine-source/Compute/apps/metaengine-browser/src/windows-native-read-environment.mjs';

const root = '/workspace/metaengine-source/Compute';
const vaultFile = root + '/infra/client-state-runtime/local-vault-key.mjs';
const pgFile = root + '/infra/client-state-runtime/owned-postgres-process.mjs';
const originalBlobs = {
  vault: '71a1a1a4f1ebb729a0325aa45661890bdfd60c00',
  postgres: 'd785eba35cc5d822963076c3ea4f249ad7beb5a4',
};
const beforeVault = execFileSync('git', ['show', originalBlobs.vault], {cwd: root, encoding: 'utf8'});
const beforePg = execFileSync('git', ['show', originalBlobs.postgres], {cwd: root, encoding: 'utf8'});
const afterVault = await readFile(vaultFile, 'utf8');
const afterPg = await readFile(pgFile, 'utf8');
const stripModule = (source, file) => source
  .replace(/^import[^\n]*;\r?\n/gm, '')
  .replace(/^export /gm, '')
  .replaceAll('import.meta.url', JSON.stringify(pathToFileURL(file).href));
const cRoot = {SystemRoot: 'C:\\Windows', SYSTEMROOT: 'C:\\Windows', WINDIR: 'C:\\Windows'};
const denied = [
  ['different system drive', {SystemRoot: 'D:\\Windows', SYSTEMROOT: 'D:\\Windows', WINDIR: 'D:\\Windows'}],
  ['conflicting root aliases', {...cRoot, SYSTEMROOT: 'D:\\Windows'}],
  ['missing declared root', {}],
  ['invalid provided temp context', {...cRoot, TEMP: '\\\\review-fixture.invalid\\share'}],
];
const data = 'D:\\ReviewFixture\\state\\pg17';
const bin = 'D:\\ReviewFixture\\bundle\\runtime\\postgresql\\bin';
const absence = () => Object.assign(Error('inert_fixture_missing'), {code: 'ENOENT'});

function vault(source, environment) {
  const audit = {reads: 0, creates: 0, writes: 0, native: 0};
  const context = {
    process: {platform: 'win32', env: environment, argv: []}, Buffer, URL,
    fixedWindowsNativeReadEnvironment, fileURLToPath, pathToFileURL,
    ...Object.fromEntries(['isAbsolute', 'join', 'resolve', 'relative'].map(name => [name, path.win32[name]])),
    chmod: async () => {throw Error('unexpected_posix_chmod');},
    realpath: async file => {audit.reads++; return file;},
    lstat: async () => {audit.reads++; return {isDirectory: () => true, isFile: () => true,
      isSymbolicLink: () => false, nlink: 1, size: 65};},
    readFile: async () => {audit.reads++; return '17\n';},
    open: async () => {audit.creates++; return {writeFile: async () => {audit.writes++;},
      sync: async () => {}, close: async () => {}};},
    randomBytes: () => {throw Error('unexpected_random_key_creation');},
    spawnSync: () => {audit.native++; return {status: 0};},
  };
  const api = vm.runInNewContext(stripModule(source, vaultFile) + '\n({initializeLocalVaultKey})', context);
  return {audit, invoke: () => api.initializeLocalVaultKey({dataDirectory: data})};
}

function postgres(source, environment) {
  const audit = {reads: 0, controls: [], nativeQueries: 0};
  const context = {
    process: {platform: 'win32', env: environment, pid: 9001}, Buffer, path: path.win32,
    fixedWindowsNativeReadEnvironment, randomUUID: () => 'inert-review-fixture',
    execFile: () => {throw Error('unexpected_real_exec');},
    spawn: () => {throw Error('unexpected_real_spawn');},
    promisify: () => () => {audit.nativeQueries++; return Promise.reject(Error('unexpected_native_inventory'));},
    fs: {lstat: async () => {audit.reads++; throw absence();},
      realpath: async file => {audit.reads++; return file;},
      writeFile: async () => {throw Error('unexpected_diagnostic_write');}},
    net: {}, setTimeout, clearTimeout,
    inertDirectory: async file => {audit.reads++; return path.win32.normalize(file);},
    inertRegular: async file => {audit.reads++; return file;},
    inertClosed: async () => {audit.reads++; return true;},
    inertPid: async () => {audit.reads++; return {pid: 123, status: 'ready', postmasterStartIdentity: '1790000000'};},
    inertControl: async (file, args) => {audit.controls.push({file, args});},
  };
  const inertFacets = `
canonicalDirectory=inertDirectory;
regularFile=inertRegular;
portClosed=inertClosed;
pidFileIdentity=inertPid;
boundedPrivateDiagnostics=async()=>null;
runOwnedPostgresControlProcess=inertControl;
({startOwnedWindowsPostgres});`;
  const api = vm.runInNewContext(stripModule(source, pgFile) + '\n' + inertFacets, context);
  return {audit, invoke: () => api.startOwnedWindowsPostgres({pgBinDir: bin, pgDataDir: data,
    databasePort: 25434, env: environment, startupTimeoutMs: 1000})};
}

for (const [name, environment] of denied) {
  test('original staged regression: ' + name + ' reaches inert key create and PG start before HOLD', async () => {
    const key = vault(beforeVault, environment);
    await assert.rejects(key.invoke());
    assert.equal(key.audit.creates, 1);
    assert.equal(key.audit.writes, 0);
    assert.equal(key.audit.native, 0);
    const pg = postgres(beforePg, environment);
    await assert.rejects(pg.invoke(), {code: 'runtime_cleanup_unconfirmed'});
    assert.equal(pg.audit.controls.length, 1);
    assert.equal(pg.audit.controls[0].args[0], 'start');
    assert.equal(pg.audit.nativeQueries, 0);
  });
  test('current preflight: ' + name + ' has zero filesystem/native/PG effects', async () => {
    const key = vault(afterVault, environment);
    await assert.rejects(key.invoke());
    assert.deepEqual(key.audit, {reads: 0, creates: 0, writes: 0, native: 0});
    const pg = postgres(afterPg, environment);
    await assert.rejects(pg.invoke(), {code: 'owned_postgres_process_inventory_unavailable'});
    assert.deepEqual(pg.audit, {reads: 0, controls: [], nativeQueries: 0});
  });
}
