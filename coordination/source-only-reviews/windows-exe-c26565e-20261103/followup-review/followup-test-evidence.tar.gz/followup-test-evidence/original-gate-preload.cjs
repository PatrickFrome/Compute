// Test-only redirection to the staged pre-fix byte gate; never a production loader.
const Module = require('node:module');
const path = require('node:path');
const target = '/workspace/metaengine-source/Compute/apps/metaengine-browser/scripts/custom-electron-package-gate.cjs';
const originalGate = path.join(__dirname, 'original-custom-electron-package-gate.cjs');
const originalLoad = Module._load;
Module._load = function(request, parent, isMain) {
  const resolved = Module._resolveFilename(request, parent, isMain);
  return originalLoad.call(this, resolved === target ? originalGate : request, parent, isMain);
};
