'use strict';
// Regression evidence only: run the current inert tests against the exact
// staged baseline gate. Never used by production packaging or runtime code.
const fs = require('node:fs');
const Module = require('node:module');
const path = require('node:path');
const target = '/workspace/metaengine-source/Compute/apps/metaengine-browser/scripts/custom-electron-package-gate.cjs';
const fixture = '/workspace/metaengine-followup-evidence/pe-index-baseline-gate.cjs';
const baseline = new Module(target, module);
baseline.filename = target;
baseline.paths = Module._nodeModulePaths(path.dirname(target));
baseline._compile(fs.readFileSync(fixture, 'utf8'), target);
require.cache[target] = baseline;
