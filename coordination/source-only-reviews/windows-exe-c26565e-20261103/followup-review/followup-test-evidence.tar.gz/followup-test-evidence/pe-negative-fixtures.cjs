'use strict';
// Isolated byte-parser regression evidence. No project module is imported and
// no PE image or downloaded package code is executed.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const vm = require('node:vm');
const out = __dirname;
const snapshot = path.join(out, 'pe-upstream/reviewed-custom-electron-package-gate.cjs');
const source = fs.readFileSync(snapshot, 'utf8');
const start = source.indexOf('function peExecutableDigest(');
const end = source.indexOf('\n// Mirror of the builder', start);
if (start < 0 || end < 0) throw new Error('expected_original_gate_function_missing');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const marker = Buffer.from('electron_browser_guardian_original_main\0');
const digest = vm.runInNewContext('(' + source.slice(start, end).trim() + ')', {
  Buffer,
  sha,
  STATIC_BINDING: marker,
  stop: reason => { throw new Error('custom_electron_package_' + reason); },
}, { timeout: 1000 });

// Synthetic PE32+ byte layout for parser testing only. This is not an Electron
// build, not Windows qualification, and not evidence of a runnable PE image.
const pe = 0x80;
const opt = pe + 24;
const sectionTable = opt + 0xf0;
const base = Buffer.alloc(0x1000);
base.write('MZ');
base.writeUInt32LE(pe, 0x3c);
base.write('PE\0\0', pe);
base.writeUInt16LE(0x8664, pe + 4);
base.writeUInt16LE(4, pe + 6);
base.writeUInt16LE(0xf0, pe + 20);
base.writeUInt16LE(0x22, pe + 22);
base.writeUInt16LE(0x20b, opt);
base.writeUInt32LE(0x1000, opt + 16);
base.writeUInt32LE(0x1000, opt + 20);
base.writeBigUInt64LE(0x140000000n, opt + 24);
base.writeUInt32LE(0x1000, opt + 32);
base.writeUInt32LE(0x200, opt + 36);
base.writeUInt32LE(0x5000, opt + 56);
base.writeUInt32LE(0x400, opt + 60);
base.writeUInt16LE(2, opt + 68);
base.writeUInt16LE(0x8160, opt + 70);
base.writeUInt32LE(16, opt + 108);
const sections = [
  ['.text', 0x1000, 0x400, 0x60000020],
  ['.rdata', 0x2000, 0x600, 0x40000040],
  ['.data', 0x3000, 0x800, 0xc0000040],
  ['.rsrc', 0x4000, 0xa00, 0x40000040],
];
for (const [i, [name, rva, raw, flags]] of sections.entries()) {
  const off = sectionTable + i * 40;
  base.write(name, off);
  base.writeUInt32LE(0x200, off + 8);
  base.writeUInt32LE(rva, off + 12);
  base.writeUInt32LE(0x200, off + 16);
  base.writeUInt32LE(raw, off + 20);
  base.writeUInt32LE(flags, off + 36);
}
base.fill(0x90, 0x400, 0x600);
base[0x400] = 0xc3;
marker.copy(base, 0x620);
base.write('KERNEL32.dll\0', 0x6a0);
base.write('baseline data\0', 0x820);
base.write('baseline resource\0', 0xa80);
const baseDigest = digest(base, 'fixture_baseline');
const cases = [];
function check(name, mutation, expected) {
  let bytes = Buffer.from(base);
  const replacement = mutation(bytes);
  if (replacement) bytes = replacement;
  let same = false;
  let actualDigest = null;
  let error = null;
  try { actualDigest = digest(bytes, name); same = actualDigest === baseDigest; }
  catch (e) { error = e.message; }
  const changedOffsets = [];
  const max = Math.max(base.length, bytes.length);
  for (let i = 0; i < max; i++) if (base[i] !== bytes[i]) changedOffsets.push(i);
  const result = {
    name, expected, same_text_identity: same,
    full_bytes_equal: bytes.equals(base), sha256: sha(bytes), pe_text_sha256: actualDigest,
    changed_offsets_hex: changedOffsets.map(i => '0x' + i.toString(16)), error,
  };
  const passed = expected === 'same_identity' ? same && !bytes.equals(base)
    : expected === 'different_identity' ? !same && !error
    : Boolean(error);
  result.fixture_expectation_passed = passed;
  cases.push(result);
  if (!passed) process.exitCode = 1;
}
check('entry_point_changed', b => b.writeUInt32LE(0x1010, opt + 16) && undefined, 'same_identity');
check('import_directory_changed', b => { b.writeUInt32LE(0x20a0, opt + 112 + 8); b.writeUInt32LE(40, opt + 112 + 12); }, 'same_identity');
check('tls_directory_changed', b => { b.writeUInt32LE(0x3020, opt + 112 + 9 * 8); b.writeUInt32LE(40, opt + 112 + 9 * 8 + 4); }, 'same_identity');
check('rdata_permissions_changed_to_rwx', b => { b.writeUInt32LE(0xe0000040, sectionTable + 40 + 36); }, 'same_identity');
check('import_name_bytes_changed', b => { b.write('evil.dll\0', 0x6a0); }, 'same_identity');
check('data_section_bytes_changed', b => { b[0x820] ^= 0xff; }, 'same_identity');
check('resource_section_bytes_changed', b => { b[0xa80] ^= 0xff; }, 'same_identity');
check('certificate_directory_changed', b => { b.writeUInt32LE(0xf00, opt + 112 + 4 * 8); b.writeUInt32LE(0x80, opt + 112 + 4 * 8 + 4); }, 'same_identity');
check('overlay_byte_changed', b => { b[0xe00] = 0x41; }, 'same_identity');
check('overlay_appended', b => Buffer.concat([b, Buffer.from('unchecked-overlay')]), 'same_identity');
check('text_control_changed', b => { b[0x410] ^= 0xff; }, 'different_identity');
check('marker_control_missing', b => { b.fill(0, 0x620, 0x620 + marker.length); }, 'rejected');
const evidence = {
  schema: 'metaengine.review.pe-negative-fixtures.v1',
  scope: 'isolated original peExecutableDigest function; synthetic nonexecuted PE-shaped buffers',
  reviewed_source_sha256: sha(Buffer.from(source)),
  baseline_sha256: sha(base), baseline_pe_text_sha256: baseDigest,
  cases, all_fixture_expectations_passed: cases.every(c => c.fixture_expectation_passed),
  unsafe_false_identity_cases: cases.filter(c => c.same_text_identity && !c.full_bytes_equal).length,
  windows_code_executed: false, project_modules_imported: false,
};
fs.writeFileSync(path.join(out, 'pe-negative-fixtures.json'), JSON.stringify(evidence, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'pe-negative-fixture-baseline.bin'), base);
process.stdout.write(JSON.stringify(evidence, null, 2) + '\n');
