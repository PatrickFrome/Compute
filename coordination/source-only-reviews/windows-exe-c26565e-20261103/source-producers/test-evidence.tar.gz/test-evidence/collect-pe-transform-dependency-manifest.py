"""Read verified npm archives as data; never import or execute their code."""
from pathlib import Path, PurePosixPath
import base64
import hashlib
import json
import posixpath
import re
import tarfile

ROOT = Path('/workspace/metaengine-next-evidence')
UPSTREAM = Path('/workspace/metaengine-followup-evidence/pe-upstream')
LOCK = Path('/workspace/metaengine-source/Compute/apps/metaengine-browser/package-lock.json')
lock = json.loads(LOCK.read_text())
PACKAGE_INPUTS = {
    'resedit': ('node_modules/resedit', UPSTREAM / 'resedit-1.7.2.tgz'),
    'pe-library': ('node_modules/pe-library', UPSTREAM / 'pe-library-0.4.1.tgz'),
}
packages = {}
file_data = {}
for name, (lock_path, archive) in PACKAGE_INPUTS.items():
    pin = lock['packages'][lock_path]
    blob = archive.read_bytes()
    sri = 'sha512-' + base64.b64encode(hashlib.sha512(blob).digest()).decode()
    if sri != pin['integrity']:
        raise ValueError('archive SRI mismatch: ' + name)
    members = {}
    with tarfile.open(archive, 'r:gz') as tf:
        for member in tf.getmembers():
            if not member.name.startswith('package/'):
                raise ValueError('unexpected archive root')
            rel = member.name.removeprefix('package/')
            if not rel and member.isdir():
                continue
            path = PurePosixPath(rel)
            if path.is_absolute() or '..' in path.parts:
                raise ValueError('unsafe archive path')
            if member.issym() or member.islnk():
                raise ValueError('archive link unsupported')
            if member.isfile():
                if rel in members:
                    raise ValueError('duplicate archive path')
                members[rel] = tf.extractfile(member).read()
    metadata = json.loads(members['package.json'])
    if metadata['name'] != name or metadata['version'] != pin['version']:
        raise ValueError('archive package identity mismatch')
    cjs = metadata.get('exports', {}).get('node', {}).get('require')
    if cjs != './dist/index.js' or metadata.get('main') != './dist/index.js':
        raise ValueError('unexpected CJS entry')
    packages[name] = {
        'version': pin['version'],
        'lock_path': lock_path,
        'resolved': pin['resolved'],
        'archive_path': str(archive),
        'archive_sha256': hashlib.sha256(blob).hexdigest(),
        'lock_integrity': pin['integrity'],
        'actual_integrity': sri,
        'sri_matches': True,
        'cjs_entry': 'dist/index.js',
        'declared_dependencies': metadata.get('dependencies', {}),
        'optional_dependencies': metadata.get('optionalDependencies', {}),
        'package_json_sha256': hashlib.sha256(members['package.json']).hexdigest(),
        'package_json_bytes': len(members['package.json']),
    }
    file_data[name] = members

if packages['resedit']['declared_dependencies'] != {'pe-library': '^0.4.1'}:
    raise ValueError('unexpected resedit dependencies')
if packages['pe-library']['declared_dependencies']:
    raise ValueError('unexpected pe-library dependencies')

require_call = re.compile(r'(?<![\w$])require\s*\(')
static_require = re.compile(r'''(?<![\w$])require\s*\(\s*(['"])([^'"\r\n]+)\1\s*\)''')
dynamic_import = re.compile(r'\bimport\s*\(')
pending = [('resedit', 'dist/index.js')]
visited = set()
modules = []
external_edges = set()
while pending:
    package, rel = pending.pop()
    key = (package, rel)
    if key in visited:
        continue
    visited.add(key)
    if not rel.startswith('dist/') or '/_esm/' in rel or not rel.endswith('.js'):
        raise ValueError('non-CJS module in static closure: ' + str(key))
    data = file_data[package].get(rel)
    if data is None:
        raise ValueError('missing CJS module: ' + str(key))
    source = data.decode('utf-8')
    imports = list(static_require.finditer(source))
    if len(list(require_call.finditer(source))) != len(imports):
        raise ValueError('nonliteral require needs manual review: ' + str(key))
    if dynamic_import.search(source):
        raise ValueError('dynamic import needs manual review: ' + str(key))
    edges = []
    for match in imports:
        spec = match.group(2)
        if spec.startswith('.'):
            target_package = package
            target_rel = posixpath.normpath(posixpath.join(posixpath.dirname(rel), spec))
            if target_rel.startswith('../') or target_rel.startswith('/'):
                raise ValueError('relative import escapes package')
        elif spec == 'pe-library' and package == 'resedit':
            target_package = 'pe-library'
            target_rel = packages[target_package]['cjs_entry']
            external_edges.add((package, spec, target_package))
        else:
            raise ValueError('unexpected bare dependency: ' + str((package, rel, spec)))
        if target_rel not in file_data[target_package]:
            raise ValueError('unresolved literal import')
        edges.append({'specifier': spec, 'package': target_package, 'path': target_rel})
        pending.append((target_package, target_rel))
    modules.append({
        'package': package, 'path': rel,
        'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
        'literal_require_edges': edges,
    })

modules.sort(key=lambda x: (x['package'], x['path']))
for name in packages:
    packages[name]['reachable_cjs_modules'] = sum(x['package'] == name for x in modules)

report = {
    'schema': 'metaengine.review.pe-transform-dependency-manifest.v1',
    'purpose': 'read-only exact CommonJS ingredient manifest for a future byte-transform producer; no admission or execution qualification',
    'lock_file': str(LOCK),
    'lock_sha256': hashlib.sha256(LOCK.read_bytes()).hexdigest(),
    'source_archives_verified_against_lock_sri': True,
    'entry_package': 'resedit', 'entry_path': 'dist/index.js',
    'resolution_policy': 'explicit Node CommonJS require condition, literal relative paths, resedit -> exact pe-library 0.4.1; reject other resolution',
    'packages': packages,
    'modules': modules,
    'external_package_edges': [
        {'from_package': a, 'specifier': b, 'resolved_package': c}
        for a, b, c in sorted(external_edges)
    ],
    'node_builtin_requires_found': [],
    'nonliteral_requires_found': [],
    'dynamic_imports_found': [],
    'closure_scope': 'static literal CommonJS require closure from the pinned entry; includes modules loaded at import time for unused signing exports',
    'analysis_limit': 'Static source inspection is not a JavaScript semantics proof or a runtime loader test. Installed resolution, links, package contents, cache, and TOCTOU must be handled separately before execution.',
    'archive_code_executed': False,
    'dependencies_installed': False,
    'windows_qualified': False,
    'authority_effect': False,
}
payload = json.dumps(report, indent=2) + '\n'
target = ROOT / 'pe-transform-dependency-manifest.json'
target.write_text(payload)
print(json.dumps({
    'manifest': str(target), 'manifest_sha256': hashlib.sha256(payload.encode()).hexdigest(),
    'modules': len(modules),
    'per_package_modules': {name: value['reachable_cjs_modules'] for name, value in packages.items()},
    'external_package_edges': report['external_package_edges'],
    'archive_code_executed': False,
}, indent=2))
