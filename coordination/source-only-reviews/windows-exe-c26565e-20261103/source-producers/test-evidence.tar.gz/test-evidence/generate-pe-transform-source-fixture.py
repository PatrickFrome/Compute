#!/usr/bin/env python3
"""Reproduce the 63-file PE source-byte test fixture using Python stdlib only.

Read the checked-in transform catalog and package lock under --app. Read four
already acquired .tgz archives under --archives, verify their lock SRI and each
selected catalog file, and write --output exclusively as a NEW JSON file.
Archives are read as data: nothing is extracted, imported, installed or run.
The fixture contains third-party source bytes as base64; keep it out of public
evidence bundles that intentionally distribute only hashes and this generator.
Print a reproducibility/provenance report to stdout.
"""

import argparse
import base64
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
from urllib.parse import urlsplit


def generate(app, archives, output):
    if output.exists() or output.is_symlink():
        raise ValueError('output_must_be_new')
    catalog_bytes = (app / 'build/custom-electron-transform-inputs.json').read_bytes()
    catalog = json.loads(catalog_bytes)
    lock_bytes = (app / 'package-lock.json').read_bytes()
    lock = json.loads(lock_bytes)
    if (catalog.get('schema') != 'metaengine.custom-electron.transform-input-catalog.v1'
            or len(catalog['modules']) != 52 or len(catalog['reference_sources']) != 9):
        raise ValueError('unsupported_catalog')

    owners = {}
    for item in [*catalog['packages'].values(), *catalog['reference_sources']]:
        pin = lock['packages'][item['lock_path']]
        if (pin['version'] != item['version'] or pin['resolved'] != item['resolved']
                or pin['integrity'] != item['lock_integrity']):
            raise ValueError('catalog_lock_drift:' + item['lock_path'])
        owners.setdefault(item['lock_path'], pin)

    records = []
    for item in catalog['packages'].values():
        records.append((item['lock_path'], 'package.json', item['package_json_bytes'],
                        item['package_json_sha256']))
    for item in catalog['modules']:
        records.append((catalog['packages'][item['package']]['lock_path'], item['path'],
                        item['bytes'], item['sha256']))
    for item in catalog['reference_sources']:
        records.append((item['lock_path'], item['path'], item['bytes'], item['sha256']))
    if len(records) != 63:
        raise ValueError('source_record_count_invalid')
    files, archive_records = {}, []
    for owner, pin in owners.items():
        archive_name = PurePosixPath(urlsplit(pin['resolved']).path).name
        if not archive_name.endswith('.tgz'):
            raise ValueError('archive_name_invalid:' + owner)
        archive_bytes = (archives / archive_name).read_bytes()
        integrity = 'sha512-' + base64.b64encode(hashlib.sha512(archive_bytes).digest()).decode('ascii')
        if integrity != pin['integrity']:
            raise ValueError('archive_sri_mismatch:' + archive_name)
        archive_sha = hashlib.sha256(archive_bytes).hexdigest()
        for item in catalog['packages'].values():
            if item['lock_path'] == owner and archive_sha != item['archive_sha256']:
                raise ValueError('archive_sha256_mismatch:' + archive_name)
        archive_records.append({'lock_path': owner, 'archive': archive_name,
                                'integrity': integrity, 'sha256': archive_sha})
        with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as archive:
            members = {}
            for member in archive.getmembers():
                members.setdefault(member.name, []).append(member)
            for record_owner, relative, length, digest in records:
                if record_owner != owner:
                    continue
                parts = PurePosixPath(relative).parts
                if (not parts or relative.startswith('/') or '\\' in relative
                        or any(part in ('.', '..') for part in relative.split('/'))):
                    raise ValueError('catalog_path_invalid:' + relative)
                selected = members.get('package/' + relative, [])
                if len(selected) != 1 or not selected[0].isreg() or selected[0].size != length:
                    raise ValueError('archive_member_invalid:' + relative)
                stream = archive.extractfile(selected[0])
                if stream is None:
                    raise ValueError('archive_member_unreadable:' + relative)
                with stream:
                    data = stream.read(length + 1)
                if len(data) != length or hashlib.sha256(data).hexdigest() != digest:
                    raise ValueError('catalog_file_hash_mismatch:' + relative)
                key = owner + '/' + relative
                if key in files:
                    raise ValueError('duplicate_source_record:' + key)
                files[key] = base64.b64encode(data).decode('ascii')
    if len(files) != 63:
        raise ValueError('source_inventory_incomplete')
    fixture = (json.dumps({'lock_base64': base64.b64encode(lock_bytes).decode('ascii'),
                           'files_base64': files}) + '\n').encode('utf-8')
    # Exclusive creation also protects against an output appearing after the
    # initial check. Never resolve a prospective output symlink to its target.
    with output.open('xb') as destination:
        destination.write(fixture)
    return {'scope': 'READ_ONLY_PINNED_ARCHIVE_BYTES', 'file_count': len(files),
            'catalog_sha256': hashlib.sha256(catalog_bytes).hexdigest(),
            'lock_sha256': hashlib.sha256(lock_bytes).hexdigest(),
            'archives': archive_records, 'fixture_bytes': len(fixture),
            'fixture_sha256': hashlib.sha256(fixture).hexdigest(),
            'packages_installed': False, 'downloaded_code_executed': False,
            'archives_extracted': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app', required=True, type=Path,
                        help='Source apps/metaengine-browser directory with catalog and lock')
    parser.add_argument('--archives', required=True, type=Path,
                        help='Directory containing the four pre-acquired lock-pinned .tgz files')
    parser.add_argument('--output', required=True, type=Path,
                        help='NEW fixture JSON file; its parent must already exist')
    args = parser.parse_args()
    try:
        report = generate(args.app, args.archives, args.output)
    except (OSError, ValueError, KeyError, TypeError, tarfile.TarError) as error:
        parser.exit(1, 'fixture_generation_failed:' + str(error) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
