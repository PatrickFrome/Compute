'use strict';
// A precondition audit for a FUTURE expected-image serializer. This is not a
// transform verifier: resource serialization and indirect loader references
// remain unresolved, so even a successful audit returns HOLD. The production
// package gate continues to require exact whole-image equality.
const { createHash } = require('node:crypto');
const FUSE_SENTINEL = Buffer.from('dL7pKGdnNz796PbbjQWNKmHXBZaB9tsX');
const fail = reason => { throw Error('custom_electron_layout_' + reason); };
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const round = (value, alignment) => Math.ceil(value / alignment) * alignment;
const powerOfTwo = value => value > 0 && Number.isInteger(Math.log2(value));
function span(start, size, limit) {
  return Number.isSafeInteger(start) && Number.isSafeInteger(size) && start >= 0 && size > 0
    && start <= limit && size <= limit - start;
}
function overlaps(a, b) { return a.start < b.end && b.start < a.end; }

function readFixedLayout(image) {
  if (!Buffer.isBuffer(image) || image.length < 512 || image.length > 512 * 1024 * 1024
      || image.toString('ascii', 0, 2) !== 'MZ') fail('image_invalid');
  const nt = image.readUInt32LE(0x3c);
  if (!span(nt, 24 + 240, image.length) || image.toString('ascii', nt, nt + 4) !== 'PE\0\0'
      || image.readUInt16LE(nt + 4) !== 0x8664 || image.readUInt16LE(nt + 20) !== 240
      || image.readUInt16LE(nt + 24) !== 0x20b) fail('pe32plus_x64_required');
  if (image.readUInt32LE(nt + 12) || image.readUInt32LE(nt + 16)) fail('symbols_unsupported');
  const optional = nt + 24, table = optional + 240;
  const count = image.readUInt16LE(nt + 6);
  if (!count || count > 96 || !span(table, count * 40, image.length)
      || image.readUInt32LE(optional + 108) !== 16) fail('headers_unsupported');
  const fileAlignment = image.readUInt32LE(optional + 36);
  const sectionAlignment = image.readUInt32LE(optional + 32);
  const headers = image.readUInt32LE(optional + 60);
  if (!powerOfTwo(fileAlignment) || fileAlignment < 512 || fileAlignment > 65536
      || !powerOfTwo(sectionAlignment) || sectionAlignment < fileAlignment
      || headers !== round(table + count * 40, fileAlignment) || headers > image.length) fail('alignment_unsupported');
  const sections = [], names = new Set();
  for (let index = 0; index < count; index++) {
    const header = table + index * 40;
    const name = image.toString('ascii', header, header + 8).replace(/\0+$/, '');
    const virtualSize = image.readUInt32LE(header + 8), rva = image.readUInt32LE(header + 12);
    const size = image.readUInt32LE(header + 16), offset = image.readUInt32LE(header + 20);
    if (!/^[.A-Za-z0-9_-]+$/.test(name) || names.has(name) || !virtualSize
        || !span(offset, size, image.length) || offset < headers || offset % fileAlignment || size % fileAlignment
        || size > round(virtualSize, sectionAlignment)
        || !rva || rva % sectionAlignment || rva + round(virtualSize, sectionAlignment) > 0xffffffff) fail('section_unsupported');
    const section = { name, header, rva, virtualSize, offset, size,
      flags: image.readUInt32LE(header + 36), start: offset, end: offset + size };
    for (const previous of sections) {
      if (overlaps(section, previous) || overlaps({ start: rva, end: rva + round(virtualSize, sectionAlignment) },
        { start: previous.rva, end: previous.rva + round(previous.virtualSize, sectionAlignment) })) fail('section_overlap');
    }
    names.add(name); sections.push(section);
  }
  const directories = Array.from({ length: 16 }, (_, index) => ({
    rva: image.readUInt32LE(optional + 112 + index * 8),
    size: image.readUInt32LE(optional + 116 + index * 8),
  }));
  if (directories[4].rva || directories[4].size) fail('unsigned_image_required');
  const resource = sections.find(section => section.name === '.rsrc');
  if (!resource || resource.flags !== 0x40000040 || resource.virtualSize > resource.size
      || directories[2].rva !== resource.rva || directories[2].size !== resource.virtualSize) fail('resource_layout_unsupported');
  for (let index = 0; index < directories.length; index++) {
    if (index === 2 || index === 4) continue;
    const directory = directories[index];
    if (!directory.rva && !directory.size) continue;
    if (!directory.rva || !directory.size || !sections.some(section => section !== resource
        && directory.rva >= section.rva && directory.size <= Math.min(section.virtualSize, section.size) - (directory.rva - section.rva))) {
      fail('direct_directory_not_separate:' + index);
    }
  }
  const imageSize = image.readUInt32LE(optional + 56);
  if (imageSize !== Math.max(...sections.map(section => round(section.rva + section.virtualSize, sectionAlignment)))) fail('image_size_unsupported');
  return { nt, optional, table, headers, count, fileAlignment, sectionAlignment, sections, resource, directories };
}

function sourceFuseWrites(image, layout = readFixedLayout(image)) {
  const sentinel = image.indexOf(FUSE_SENTINEL);
  if (sentinel < 0 || image.lastIndexOf(FUSE_SENTINEL) !== sentinel) fail('unique_source_fuse_wire_required');
  const wire = sentinel + FUSE_SENTINEL.length;
  if (!span(wire, 2, image.length) || image[wire] !== 1 || image[wire + 1] < 6 || image[wire + 1] > 64) fail('fuse_wire_unsupported');
  const owner = layout.sections.find(section => section !== layout.resource
    && sentinel >= section.offset && wire + 2 + image[wire + 1] <= section.offset + Math.min(section.size, section.virtualSize));
  if (!owner || !(owner.flags & 0x40000000) || owner.flags & 0xa0000000) fail('fuse_wire_section_unsupported');
  for (let index = 0; index < image[wire + 1]; index++) {
    if (![48, 49, 114].includes(image[wire + 2 + index])) fail('source_fuse_state_unsupported');
  }
  if (image[wire + 6] === 114 || image[wire + 7] === 114) fail('required_fuse_removed');
  return [{ offset: wire + 6, value: 49 }, { offset: wire + 7, value: 49 }];
}

// Matches pe-library 0.4.1's checksum update for its generate() path. Its caller
// updates a nonzero source checksum only. This is data processing, not signing.
function peChecksum(image, checksumOffset) {
  let sum = 0;
  const update = value => { sum += value; if (sum >= 0x100000000) sum = sum % 0x100000000 + Math.floor(sum / 0x100000000); };
  const aligned = image.length - image.length % 4;
  for (let offset = 0; offset < aligned; offset += 4) if (offset !== checksumOffset) update(image.readUInt32LE(offset));
  if (aligned !== image.length) {
    let tail = 0;
    for (let index = 0; aligned + index < image.length; index++) tail |= image[aligned + index] << ((3 - index) * 8);
    update(tail);
  }
  sum = (sum & 0xffff) + (sum >>> 16); sum += sum >>> 16;
  return (sum & 0xffff) + image.length;
}

function inspectFixedLayoutTransform(source, candidate, { stage = 'FINAL_UNSIGNED' } = {}) {
  if (!['AFTER_PACK', 'FINAL_UNSIGNED'].includes(stage)) fail('stage_invalid');
  const original = readFixedLayout(source), changed = readFixedLayout(candidate);
  if (source.length !== candidate.length || original.headers !== changed.headers
      || original.table !== changed.table || original.count !== changed.count) fail('geometry_changed');
  const resource = original.resource;
  if (round(resource.virtualSize, original.sectionAlignment) !== round(changed.resource.virtualSize, original.sectionAlignment)) fail('resource_virtual_span_changed');
  const writes = sourceFuseWrites(source, original);
  const permittedHeaderFields = [original.optional + 64, original.optional + 132, resource.header + 8];
  for (let offset = 0; offset < original.headers; offset++) {
    if (permittedHeaderFields.some(start => offset >= start && offset < start + 4)) continue;
    if (source[offset] !== candidate[offset]) fail('header_or_mapping_changed:' + offset);
  }
  const checksumOffset = original.optional + 64;
  const expectedChecksum = source.readUInt32LE(checksumOffset) ? peChecksum(candidate, checksumOffset) : 0;
  if (candidate.readUInt32LE(checksumOffset) !== expectedChecksum) fail('checksum_not_expected');
  const expectedFuses = new Map(writes.map(write => [write.offset, stage === 'FINAL_UNSIGNED' ? write.value : source[write.offset]]));
  for (let offset = original.headers; offset < source.length; offset++) {
    // This range is observed and hashed below, NEVER approved or normalized.
    // Its exact expected serialization remains an explicit unresolved check.
    if (offset >= resource.offset && offset < resource.offset + resource.size) continue;
    if (candidate[offset] !== (expectedFuses.has(offset) ? expectedFuses.get(offset) : source[offset])) fail('nonresource_byte_changed:' + offset);
  }
  return Object.freeze({ schema: 'metaengine.custom-electron.direct-layout-preconditions.v1', state: 'HOLD',
    stage, source_image_sha256: hash(source), candidate_image_sha256: hash(candidate),
    resource_source_sha256: hash(source.subarray(resource.offset, resource.offset + resource.size)),
    resource_candidate_sha256: hash(candidate.subarray(resource.offset, resource.offset + resource.size)),
    scope: 'DIRECT_LAYOUT_AND_NONRESOURCE_BYTES_ONLY',
    unresolved_checks: ['IMMUTABLE_EXPECTED_ASAR_PRODUCER', 'EXACT_EXPECTED_RESOURCE_SERIALIZER',
      'INDIRECT_LOADER_REFERENCE_CLOSURE', 'EXACT_EXPECTED_WHOLE_IMAGE_COMPARISON'], authority_effect: false });
}

module.exports = { readFixedLayout, sourceFuseWrites, peChecksum, inspectFixedLayoutTransform };
