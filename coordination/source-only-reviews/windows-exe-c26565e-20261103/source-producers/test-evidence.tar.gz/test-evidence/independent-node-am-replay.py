#!/usr/bin/env python3
"""Read-only upstream inputs; replay only Git patch data in a NEW private copy.

No upstream hook/Python/build script, package installer or produced code is run.
The complete physical Node tree is checked against Git blobs after git am.
"""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess

ROOT = Path('/workspace/metaengine-source/Compute')
ELECTRON = Path('/workspace/metaengine-next-upstream/electron')
NODE = Path('/workspace/metaengine-next-upstream/node')
OUT = Path('/workspace/metaengine-next-evidence')
COPY = OUT / 'independent-node-am-worktree'
EHEAD = 'c542df1ecbc2c2978e8f53f8c7baf602404d166f'
NHEAD = 'f14cd3aa7bf9ca8df2cc5b8bb14beb0f335b1d93'
EXPECTED_POSTTREE = '92f36398f6bacb44cbba33fea5b902898ac8ef9a'
PINS = ROOT / 'apps/metaengine-browser/native/electron-original-main/electron-44.9.3-original-main-entry.pins.json'
ENV = {key: os.environ[key] for key in ('PATH', 'LANG', 'LC_ALL', 'TMPDIR') if key in os.environ}
ENV.update({'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null',
            'GIT_NO_REPLACE_OBJECTS': '1', 'GIT_TERMINAL_PROMPT': '0',
            'GIT_ALTERNATE_OBJECT_DIRECTORIES': str(NODE / '.git/objects'),
            'GIT_COMMITTER_NAME': 'Independent source replay',
            'GIT_COMMITTER_EMAIL': 'source-replay@example.invalid',
            'GIT_COMMITTER_DATE': '2000-01-01T00:00:00Z'})
OPTIONS = ['-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false',
           '-c', 'core.autocrlf=false', '-c', 'core.symlinks=true',
           '-c', 'core.attributesfile=/dev/null', '-c', 'commit.gpgsign=false',
           '-c', 'am.threeWay=false', '-c', 'gc.auto=0']


def git(root, *args, data=None):
    result = subprocess.run(['git', '--no-optional-locks', '-C', str(root), *OPTIONS, *args],
                            env=ENV, input=data, capture_output=True)
    if result.returncode:
        raise RuntimeError('git operation failed: ' + ' '.join(args) + '\n' + result.stderr.decode('utf8', 'replace'))
    return result.stdout


def oid(kind, body):
    return hashlib.sha1(kind.encode() + b' ' + str(len(body)).encode() + b'\0' + body).hexdigest()


def head(root):
    return git(root, 'rev-parse', 'HEAD').decode().strip()


def unchanged_status(root):
    return git(root, 'status', '--porcelain=v1', '--untracked-files=all', '--ignore-submodules=none')


assert head(ELECTRON) == EHEAD and head(NODE) == NHEAD
assert unchanged_status(ELECTRON) == unchanged_status(NODE) == b''
assert not COPY.exists(), 'replay destination must be new'
COPY.mkdir()
template = OUT / 'independent-empty-git-template'
template.mkdir(exist_ok=True)
assert not any(template.iterdir())
git(COPY, 'init', '--object-format=sha1', '--template=' + str(template), '.')
git(COPY, 'checkout', '--detach', NHEAD)

list_bytes = git(ELECTRON, 'cat-file', 'blob', EHEAD + ':patches/node/.patches')
list_oid = git(ELECTRON, 'rev-parse', EHEAD + ':patches/node/.patches').decode().strip()
assert oid('blob', list_bytes) == list_oid
names = list_bytes.decode('utf8').splitlines()
assert len(names) == len(set(names)) == 64
assert all(re.fullmatch(r'[a-z0-9_.-]+\.patch', name) for name in names)
mailbox = []
patch_records = []
for order, name in enumerate(names, 1):
    spec = EHEAD + ':patches/node/' + name
    patch = git(ELECTRON, 'cat-file', 'blob', spec)
    blob = git(ELECTRON, 'rev-parse', spec).decode().strip()
    assert oid('blob', patch) == blob
    patch_records.append({'order': order, 'path': name, 'git_blob': blob,
                          'bytes': len(patch), 'sha256': hashlib.sha256(patch).hexdigest()})
    # Match the upstream read_patch message-only metadata insertion. Keep CR.
    lines = []
    added = False
    for line in io.StringIO(patch.decode('utf8'), newline='').readlines():
        if not added and (line.startswith('diff -') or line.startswith('---')):
            lines.extend(['Patch-Dir: src/electron/patches/node\n', 'Patch-Filename: ' + name + '\n'])
            added = True
        lines.append(line)
    assert added
    mailbox.append(''.join(lines).encode('utf8'))

result = subprocess.run(['git', '--no-optional-locks', '-C', str(COPY), *OPTIONS,
                         'am', '--keep-non-patch', '--keep-cr'], env=ENV,
                        input=b''.join(mailbox), capture_output=True)
(OUT / 'independent-node-am-output.log').write_bytes(result.stdout + result.stderr)
assert result.returncode == 0, result.stderr.decode('utf8', 'replace')
posttree = git(COPY, 'rev-parse', 'HEAD^{tree}').decode().strip()
assert posttree == EXPECTED_POSTTREE
assert int(git(COPY, 'rev-list', '--count', NHEAD + '..HEAD')) == 64
assert unchanged_status(COPY) == b''
tree_bytes = git(COPY, 'cat-file', 'tree', posttree)
assert oid('tree', tree_bytes) == posttree

listing = git(COPY, 'ls-tree', '-rz', '--full-tree', posttree)
inventory = []
expected_paths = set()
for record in listing.split(b'\0'):
    if not record:
        continue
    metadata, raw_name = record.split(b'\t', 1)
    mode, kind, blob = metadata.decode().split()
    relative = raw_name.decode('utf8')
    assert mode in ('100644', '100755', '120000') and kind == 'blob'
    assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
    expected_paths.add(relative)
    file = COPY / relative
    info = file.lstat()
    if mode == '120000':
        assert stat.S_ISLNK(info.st_mode)
        content = os.fsencode(os.readlink(file))
    else:
        assert stat.S_ISREG(info.st_mode) and not file.is_symlink() and info.st_nlink == 1
        assert bool(info.st_mode & 0o111) == (mode == '100755')
        content = file.read_bytes()
    assert oid('blob', content) == blob, 'physical content mismatch: ' + relative
    inventory.append({'path': relative, 'mode': mode, 'git_blob': blob,
                      'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()})
physical = set()
for current, directories, files in os.walk(COPY, followlinks=False):
    if Path(current) == COPY:
        directories.remove('.git')
    for name in directories[:]:
        target = Path(current) / name
        if target.is_symlink():
            physical.add(target.relative_to(COPY).as_posix())
            directories.remove(name)
    physical.update((Path(current) / name).relative_to(COPY).as_posix() for name in files)
assert physical == expected_paths
assert len(inventory) == 46474
inventory_bytes = json.dumps(inventory, sort_keys=True, separators=(',', ':')).encode()
(OUT / 'independent-node-am-file-inventory.json').write_bytes(inventory_bytes + b'\n')
selected = []
for row in json.loads(PINS.read_text())['node_files_after_electron_patches']:
    actual = hashlib.sha256((COPY / row['path']).read_bytes()).hexdigest()
    assert actual == row['sha256']
    selected.append({'path': row['path'], 'sha256': actual})
assert unchanged_status(ELECTRON) == unchanged_status(NODE) == b''
summary = {'schema': 'metaengine.independent-node-am-replay-review.v1',
           'electron_commit': EHEAD, 'node_base_commit': NHEAD,
           'node_base_tree': git(NODE, 'rev-parse', NHEAD + '^{tree}').decode().strip(),
           'patch_list_git_blob': list_oid, 'patch_list_sha256': hashlib.sha256(list_bytes).hexdigest(),
           'patch_count': len(names), 'patches': patch_records,
           'upstream_equivalent_flags': ['--keep-non-patch', '--keep-cr'],
           'threeway': False, 'all_patch_paths_applied': True,
           'node_posttree': posttree, 'matches_other_producer': posttree == EXPECTED_POSTTREE,
           'physical_tree_entries_verified': len(inventory),
           'physical_symlinks_verified': sum(row['mode'] == '120000' for row in inventory),
           'physical_file_inventory_sha256': hashlib.sha256(inventory_bytes).hexdigest(),
           'total_source_bytes_verified': sum(row['bytes'] for row in inventory),
           'selected_interface_pins_verified': selected, 'original_checkouts_unchanged': True,
           'whole_dependency_closure': 'HOLD_NOT_VERIFIED', 'native_or_build_execution': False}
(OUT / 'independent-node-am-replay.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key not in ('patches', 'selected_interface_pins_verified')}, indent=2))
