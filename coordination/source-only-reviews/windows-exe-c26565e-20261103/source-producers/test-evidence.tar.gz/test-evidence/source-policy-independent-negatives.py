#!/usr/bin/env python3
"""Additional independent policy negatives; only small inert Git fixtures."""
import importlib.util
import os
from pathlib import Path
import unittest

test_file = Path('/workspace/metaengine-source/Compute/apps/metaengine-browser/test/test_custom_electron_source_policy.py')
spec = importlib.util.spec_from_file_location('independent_policy_fixture', test_file)
fixtures = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures)
policy = fixtures.policy
run = fixtures.run


class IndependentPolicyNegatives(unittest.TestCase):
    fixture = fixtures.ComponentPolicyTests.fixture

    def test_actual_replacement_ref_is_refused(self):
        _, electron, node, _ = self.fixture()
        base = policy.COMPONENTS['node'][0]
        head = run(node, 'rev-parse', 'HEAD').decode().strip()
        run(node, 'replace', base, head)
        with self.assertRaisesRegex(ValueError, 'replacement_objects_forbidden'):
            policy.verify_component_tree(electron, node, 'node')

    def test_actual_graft_file_is_refused(self):
        _, electron, node, _ = self.fixture()
        (node / '.git/info/grafts').write_text(policy.COMPONENTS['node'][0] + '\n')
        with self.assertRaisesRegex(ValueError, 'grafts_forbidden'):
            policy.verify_component_tree(electron, node, 'node')

    def test_included_local_promisor_or_filter_config_is_refused(self):
        root, _, node, _ = self.fixture()
        included = root / 'included-local-config'
        included.write_text('[remote "origin"]\n  promisor = true\n[filter "model"]\n  clean = untrusted-command\n')
        run(node, 'config', 'include.path', str(included))
        with self.assertRaisesRegex(ValueError, 'local_config_composition_forbidden'):
            policy.repository_controls(node)

    def test_worktree_config_cannot_hide_promisor_or_filter_config(self):
        _, _, node, _ = self.fixture()
        run(node, 'config', 'extensions.worktreeConfig', 'true')
        (node / '.git/config.worktree').write_text('[remote "origin"]\n  promisor = true\n[filter "model"]\n  clean = untrusted-command\n')
        with self.assertRaisesRegex(ValueError, 'local_config_composition_forbidden'):
            policy.repository_controls(node)

    def test_tree_parser_refuses_traversal_before_any_leaf_read(self):
        class TreeOnly:
            def __init__(self, name):
                self.data = b'100644 ' + name + b'\0' + bytes.fromhex('a' * 40)
                self.calls = 0
            def read(self, *_args, **_kwargs):
                self.calls += 1
                return 'tree', self.data
        for name in (b'..', b'.', b'../escape', b'/absolute', b'safe\\escape'):
            objects = TreeOnly(name)
            with self.assertRaisesRegex(ValueError, 'tree_path_invalid'):
                policy.tree_entries(objects, 'b' * 40)
            self.assertEqual(objects.calls, 1)

    def test_hardlinked_tracked_source_is_refused(self):
        root, electron, node, _ = self.fixture()
        os.link(node / 'main.cc', root / 'external-alias.cc')
        with self.assertRaisesRegex(ValueError, 'physical_file_alias'):
            policy.verify_component_tree(electron, node, 'node')

    def test_tracked_mode_drift_is_refused(self):
        _, electron, node, _ = self.fixture()
        (node / 'main.cc').chmod(0o755)
        with self.assertRaisesRegex(ValueError, 'physical_file_mode_mismatch'):
            policy.verify_component_tree(electron, node, 'node')

    def test_nontracked_directory_and_alias_are_refused(self):
        root, electron, node, _ = self.fixture()
        (node / 'unexpected-layout').mkdir()
        with self.assertRaisesRegex(ValueError, 'extra_physical_directory'):
            policy.verify_component_tree(electron, node, 'node')
        alias = root / 'node-alias'
        alias.symlink_to(node, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'canonical_repository_required'):
            policy.repository_controls(alias)

    def test_repo_fsmonitor_and_apply_hooks_cannot_execute(self):
        root, electron, node, _ = self.fixture()
        marker = root / 'unexpected-hook-effect'
        script = '#!/bin/sh\ntouch ' + str(marker) + '\n'
        for name in ('pre-applypatch', 'post-applypatch', 'applypatch-msg'):
            hook = node / '.git/hooks' / name
            hook.write_text(script)
            hook.chmod(0o755)
        self.assertTrue(policy.verify_component_tree(electron, node, 'node')['physical_tree_verified'])
        self.assertFalse(marker.exists())
        run(node, 'config', 'core.fsmonitor', script.replace('\n', ';'))
        with self.assertRaisesRegex(ValueError, 'partial_clone_or_external_filter_forbidden'):
            policy.verify_component_tree(electron, node, 'node')
        self.assertFalse(marker.exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
