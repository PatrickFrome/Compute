#!/usr/bin/env python3
"""Finish independent git-am evidence using explicit checkout and raw profiles.

Reads only pinned Git data; writes a NEW canonical source export. No source,
hook, build, package or native Windows code is executed.
"""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

OUT = Path('/workspace/metaengine-next-evidence')
COPY = OUT / 'independent-node-am-worktree'
RAW = OUT / 'independent-node-posttree-raw'
ELECTRON = Path('/workspace/metaengine-next-upstream/electron')
NODE = Path('/workspace/metaengine-next-upstream/node')
SOURCE = Path('/workspace/metaengine-source/Compute')
EHEAD = 'c542df1ecbc2c2978e8f53f8c7baf602404d166f'
NHEAD = 'f14cd3aa7bf9ca8df2cc5b8bb14beb0f335b1d93'
TREE = '92f36398f6bacb44cbba33fea5b902898ac8ef9a'
CRLF = {'vcbuild.bat', 'tools/msvs/find_python.cmd'}
ENV = {key: os.environ[key] for key in ('PATH', 'LANG', 'LC_ALL', 'TMPDIR') if key in os.environ}
ENV.update({'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null',
            'GIT_NO_REPLACE_OBJECTS': '1', 'GIT_TERMINAL_PROMPT': '0', 'GIT_ATTR_NOSYSTEM': '1',
            'GIT_ALTERNATE_OBJECT_DIRECTORIES': str(NODE / '.git/objects')})
OPTIONS = ['-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false',
           '-c', 'core.autocrlf=false', '-c', 'core.attributesfile=/dev/null']


def command(repo, *args):
    return ['git', '--no-optional-locks', '-C', str(repo), *OPTIONS, *args]


def git(repo, *args, data=None):
    return subprocess.check_output(command(repo, *args), env=ENV, input=data)


def oid(kind, body):
    return hashlib.sha1(kind.encode() + b' ' + str(len(body)).encode() + b'\0' + body).hexdigest()


def status(repo):
    return git(repo, 'status', '--porcelain=v1', '--untracked-files=all', '--ignore-submodules=none')


def physical_names(root, skip_git=False):
    result = set()
    for current, directories, files in os.walk(root, followlinks=False):
        if skip_git and Path(current) == root:
            directories.remove('.git')
        for name in directories[:]:
            entry = Path(current) / name
            if entry.is_symlink():
                result.add(entry.relative_to(root).as_posix())
                directories.remove(name)
        result.update((Path(current) / name).relative_to(root).as_posix() for name in files)
    return result


assert git(ELECTRON, 'rev-parse', 'HEAD').decode().strip() == EHEAD
assert git(NODE, 'rev-parse', 'HEAD').decode().strip() == NHEAD
assert status(ELECTRON) == status(NODE) == b''
assert git(COPY, 'rev-parse', 'HEAD^{tree}').decode().strip() == TREE
assert int(git(COPY, 'rev-list', '--count', NHEAD + '..HEAD')) == 64
assert status(COPY) == b''
listing = git(COPY, 'ls-tree', '-rz', '--full-tree', TREE)
records = []
for row in listing.split(b'\0'):
    if row:
        meta, name = row.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        assert mode in ('100644', '100755', '120000') and kind == 'blob'
        relative = name.decode('utf8')
        assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
        records.append((relative, mode, blob))
assert len(records) == 46474
attributes = git(COPY, 'check-attr', '-z', '--cached', '--stdin', 'eol', 'filter',
                 'working-tree-encoding', 'ident', data=b'\0'.join(name.encode() for name, _, _ in records) + b'\0').split(b'\0')
assert attributes.pop() == b'' and len(attributes) % 3 == 0
crlf = set()
for i in range(0, len(attributes), 3):
    name, key, value = attributes[i:i + 3]
    if key == b'eol' and value == b'crlf':
        crlf.add(name.decode())
    elif key != b'eol':
        assert value == b'unspecified'
assert crlf == CRLF
assert not (COPY / '.git/info/attributes').exists()
assert not RAW.exists(), 'canonical destination must be new'
RAW.mkdir()
inventory = []
conversions = []
reader = subprocess.Popen(command(COPY, 'cat-file', '--batch'), env=ENV,
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE)
try:
    for relative, mode, blob in records:
        reader.stdin.write(blob.encode() + b'\n')
        reader.stdin.flush()
        header = reader.stdout.readline().decode().split()
        assert header[:2] == [blob, 'blob']
        content = reader.stdout.read(int(header[2]))
        assert reader.stdout.read(1) == b'\n'
        assert oid('blob', content) == blob
        file = COPY / relative
        info = file.lstat()
        if mode == '120000':
            assert stat.S_ISLNK(info.st_mode)
            actual = os.fsencode(os.readlink(file))
        else:
            assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1
            assert bool(info.st_mode & 0o111) == (mode == '100755')
            actual = file.read_bytes()
        expected_checkout = content
        if relative in CRLF:
            assert b'\r' not in content
            expected_checkout = content.replace(b'\n', b'\r\n')
            conversions.append({'path': relative, 'raw_bytes': len(content), 'checkout_bytes': len(actual),
                                'raw_sha256': hashlib.sha256(content).hexdigest(),
                                'checkout_sha256': hashlib.sha256(actual).hexdigest()})
        assert actual == expected_checkout, 'unexpected checkout representation: ' + relative
        target = RAW / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if mode == '120000':
            link = os.fsdecode(content)
            assert not Path(link).is_absolute()
            assert (target.parent / link).resolve().is_relative_to(RAW.resolve())
            target.symlink_to(link)
        else:
            with target.open('xb') as stream:
                stream.write(content)
            target.chmod(0o755 if mode == '100755' else 0o644)
        inventory.append({'path': relative, 'mode': mode, 'git_blob': blob, 'bytes': len(content),
                          'raw_sha256': hashlib.sha256(content).hexdigest(),
                          'checkout_sha256': hashlib.sha256(actual).hexdigest()})
finally:
    reader.stdin.close()
    assert reader.wait(timeout=30) == 0
names = {row['path'] for row in inventory}
assert physical_names(COPY, skip_git=True) == physical_names(RAW) == names
# Independent post-write readback, not merely hashing buffers before writing.
for row in inventory:
    file = RAW / row['path']
    data = os.fsencode(os.readlink(file)) if row['mode'] == '120000' else file.read_bytes()
    assert oid('blob', data) == row['git_blob']
    assert hashlib.sha256(data).hexdigest() == row['raw_sha256']
pins = json.loads((SOURCE / 'apps/metaengine-browser/native/electron-original-main/electron-44.9.3-original-main-entry.pins.json').read_text())
selected = []
for row in pins['node_files_after_electron_patches']:
    value = hashlib.sha256((RAW / row['path']).read_bytes()).hexdigest()
    assert value == row['sha256']
    selected.append({'path': row['path'], 'sha256': value})
patch_list = git(ELECTRON, 'cat-file', 'blob', EHEAD + ':patches/node/.patches')
patches = []
for order, name in enumerate(patch_list.decode().splitlines(), 1):
    raw = git(ELECTRON, 'cat-file', 'blob', EHEAD + ':patches/node/' + name)
    blob = git(ELECTRON, 'rev-parse', EHEAD + ':patches/node/' + name).decode().strip()
    assert oid('blob', raw) == blob
    patches.append({'order': order, 'path': name, 'git_blob': blob,
                    'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
assert len(patches) == 64
manifest = json.dumps(inventory, sort_keys=True, separators=(',', ':')).encode()
(OUT / 'independent-node-am-file-inventory.json').write_bytes(manifest + b'\n')
assert status(ELECTRON) == status(NODE) == status(COPY) == b''
summary = {'schema': 'metaengine.independent-node-am-replay-review.v1',
           'electron_commit': EHEAD, 'node_base_commit': NHEAD,
           'node_base_tree': '409a26f676d83fa6e1b0bfdb1c10d6878845c071',
           'patch_count': len(patches), 'patches': patches,
           'upstream_equivalent_flags': ['--keep-non-patch', '--keep-cr'], 'threeway': False,
           'all_patch_paths_applied': True, 'node_posttree': TREE,
           'matches_independent_cached_apply_producer': True,
           'physical_checkout_entries_verified': len(inventory), 'physical_canonical_entries_verified': len(inventory),
           'physical_symlinks_verified': sum(row['mode'] == '120000' for row in inventory),
           'total_raw_source_bytes_verified': sum(row['bytes'] for row in inventory),
           'file_inventory_sha256': hashlib.sha256(manifest).hexdigest(),
           'explicit_CRLF_conversions': conversions, 'selected_interface_pins_verified': selected,
           'original_checkouts_unchanged': True, 'whole_dependency_closure': 'HOLD_NOT_VERIFIED',
           'native_or_build_execution': False, 'windows_representation_qualified': False}
(OUT / 'independent-node-am-replay.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key not in ('patches', 'selected_interface_pins_verified')}, indent=2))
