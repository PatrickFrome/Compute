# METAENGINE final source verification

Final local reconstructed commit: `b0fc979cbc794653121b7760def56dcdabcc499a`.
Final tree: `6e32a721330a43821666d63f5980f59f61565850`.
The full source runner recorded clean worktrees before and after; the outer runner also confirmed the final worktree remained clean.

All 14 verification commands completed. Thirteen exited 0; launch-source exited 1 for the expected disabled-route check. No dependencies were installed and no source files, services or databases were changed by this verification.

| Check | Result |
| --- | --- |
| verify-guardian-original-main-launch-source.py | 81 PASS, 1 expected FAIL: wire_route_authenticates_then_launches |
| verify-guardian-main-begin-model.py | 9 PASS |
| verify-guardian-main-begin-model.py --sanitize | 9 PASS; ASAN/UBSAN |
| verify-guardian-main-owner-wait-model.py | 13 PASS |
| verify-guardian-main-owner-wait-model.py --sanitize | 13 PASS; ASAN/UBSAN |
| verify-guardian-requester-session-model.py | 15 PASS |
| verify-guardian-requester-session-model.py --sanitize | 15 PASS; ASAN/UBSAN |
| Three selected Node suites | 17 PASS, 0 FAIL, 0 SKIP |
| node scripts/check-source.mjs | 292 PASS |
| verify-guardian-original-main-source.py | 23 checks PASS, 0 FAIL, 5 NOT RUN |
| Existing portable challenge test compile and execution | PASS, exit 0 |
| Existing portable challenge test compile and execution with ASAN/UBSAN | PASS, exit 0 |

The launch-source FAIL preserves the intentionally disabled production HOLD route. It was not suppressed, altered or reclassified as success. Synthetic model and portable fixture PASS results do not qualify Windows behavior, production grants, native service identity or continuous loaded-code custody.

## Retained negative authorization evidence

The pre-existing `negative-authorization.log` and `negative-authorization-sanitize.log` were retained byte-for-byte without rerunning the tests. Each records 22 PASS with CRYPTO STAND-IN, PRE-MAIN ISSUER UNPROVEN and WINDOWS NOT RUN. The ordinary log additionally records the expected mutation failure after removing rejection revocation. The retained file hashes are captured in `summary.json`.

## NOT RUN

The source runner reported exactly five missing prerequisite checks:

1. w77-pinned-openssl-regression: acquired pinned OpenSSL 3.5.9 source plus completed isolated static build.
2. w77-boringssl-regression: exact pinned public source plus isolated static crypto build.
3. electron-source-interface: exact Electron and Node-after-Electron-patches source files.
4. official-electron-header-syntax: verified official Electron header archive plus patched Node internal headers.
5. win64-cross-builds: no existing cross compiler supplied; the runner installs none.

The source Node suites also skipped `actual Windows original pipe and process references survive caller close and refuse stale/replaced peers`, which requires actual Windows named pipes, process handles and SCM readback. That grouped suite had 15 PASS and 1 SKIP.

**Windows execution: NOT RUN.** Full custom Electron build, production Main launch grant, production release positive and leak sanitizer: NOT RUN. Leak sanitizer is explicitly disabled on this ptrace host, including the portable sanitized challenge execution. Runtime loaded-code attestation and continuous code custody remain unproven.

The system OpenSSL regression passed 26 tests; this does not substitute for the missing pinned OpenSSL or BoringSSL builds.

## Environment and evidence

Linux 6.18.57 x86_64; Python 3.12.14; Node v24.19.0; g++ 14.2.0.

Exact command arrays, current directories, exit codes, test environment settings, timings and log hashes are in `summary.json`. Complete outputs are in the numbered logs. The full source runner's inner evidence, including all five NOT RUN reasons, is in `original-main-source-evidence/`. `sha256-manifest.json` covers every evidence file except the manifest itself.

